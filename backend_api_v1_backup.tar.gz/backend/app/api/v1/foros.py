"""
FASE 36 — Comunicación Avanzada

  CO-020  GET/POST  /foros                               — foros por grupo/plantel
  CO-021  GET/POST  /foros/{foro_id}/mensajes            — mensajes en un foro
  CO-022  POST      /foros/{foro_id}/mensajes/{msg_id}/responder — respuestas encadenadas
  CO-023  GET/POST  /foros/anuncios                      — tablón de anuncios oficial
"""
from __future__ import annotations
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

router = APIRouter(prefix="/foros", tags=["foros"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class ForoIn(BaseModel):
    nombre: str = Field(min_length=3, max_length=120)
    descripcion: Optional[str] = None
    tipo: str = "GRUPO"  # GRUPO | PLANTEL | GENERAL | DOCENTES | MATERIA | TUTORES
    grupo_id: Optional[uuid.UUID] = None
    plantel_id: Optional[uuid.UUID] = None
    materia_id: Optional[uuid.UUID] = None
    es_moderado: bool = False

class MensajeForoIn(BaseModel):
    asunto: str = Field(min_length=3, max_length=200)
    contenido: str = Field(min_length=5)
    adjunto_url: Optional[str] = None

class RespuestaForoIn(BaseModel):
    contenido: str = Field(min_length=2)
    adjunto_url: Optional[str] = None

class AnuncioIn(BaseModel):
    titulo: str = Field(min_length=3, max_length=200)
    contenido: str = Field(min_length=10)
    plantel_id: Optional[uuid.UUID] = None
    nivel_educativo: Optional[str] = None
    fecha_inicio: str
    fecha_fin: Optional[str] = None
    es_urgente: bool = False


# ── CO-020: Foros ─────────────────────────────────────────────────────────────

@router.get("")
async def listar_foros(
    grupo_id: Optional[uuid.UUID] = None,
    plantel_id: Optional[uuid.UUID] = None,
    materia_id: Optional[uuid.UUID] = None,
    tipo: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["f.is_active = TRUE"]
    params: dict = {}
    if grupo_id:
        filters.append("f.grupo_id = :gid"); params["gid"] = str(grupo_id)
    if plantel_id:
        filters.append("f.plantel_id = :plid"); params["plid"] = str(plantel_id)
    if materia_id:
        filters.append("f.materia_id = :mid"); params["mid"] = str(materia_id)
    if tipo:
        filters.append("f.tipo = :tipo"); params["tipo"] = tipo

    # Si el rol es PADRE_FAMILIA (nivel 5), solo puede ver foros GENERAL, PLANTEL (de su plantel), o TUTORES.
    # Los alumnos también tienen restricciones similares.
    if user.nivel_acceso == 5:
        filters.append("f.tipo IN ('GENERAL', 'PLANTEL', 'GRUPO', 'TUTORES', 'MATERIA')")

    r = await db.execute(text(f"""
        SELECT f.id, f.nombre, f.descripcion, f.tipo, f.es_moderado, f.materia_id,
               f.fecha_creacion,
               g.nombre_grupo, pl.nombre_plantel, mat.nombre_materia,
               (SELECT COUNT(*) FROM ades_mensajes_foro WHERE foro_id = f.id AND is_active) as total_mensajes
        FROM ades_foros f
        LEFT JOIN ades_grupos g ON g.id = f.grupo_id
        LEFT JOIN ades_planteles pl ON pl.id = f.plantel_id
        LEFT JOIN ades_materias mat ON mat.id = f.materia_id
        WHERE {" AND ".join(filters)}
        ORDER BY f.tipo, f.nombre
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("", status_code=201)
async def crear_foro(
    data: ForoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere Coordinador o superior")

    r = await db.execute(text("""
        INSERT INTO ades_foros
          (nombre, descripcion, tipo, grupo_id, plantel_id, materia_id, es_moderado,
           creado_por, usuario_creacion, usuario_modificacion)
        VALUES (:nom, :desc, :tipo, :gid, :plid, :mid, :mod,
                :autor, :uname, :uname)
        RETURNING id
    """), {
        "nom": data.nombre, "desc": data.descripcion, "tipo": data.tipo,
        "gid": str(data.grupo_id) if data.grupo_id else None,
        "plid": str(data.plantel_id) if data.plantel_id else None,
        "mid": str(data.materia_id) if data.materia_id else None,
        "mod": data.es_moderado,
        "autor": str(user.db_id) if user.db_id else None, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Foro creado"}



# ── CO-021: Mensajes ──────────────────────────────────────────────────────────

@router.get("/{foro_id}/mensajes")
async def listar_mensajes(
    foro_id: uuid.UUID,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT m.id, m.asunto, m.contenido, m.adjunto_url,
               m.fecha_creacion, m.usuario_creacion,
               (SELECT COUNT(*) FROM ades_respuestas_foro WHERE mensaje_id = m.id AND is_active) as respuestas
        FROM ades_mensajes_foro m
        WHERE m.foro_id = :fid AND m.is_active = TRUE AND m.mensaje_padre_id IS NULL
        ORDER BY m.fecha_creacion DESC
        LIMIT :limit OFFSET :skip
    """), {"fid": str(foro_id), "skip": skip, "limit": limit})
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/{foro_id}/mensajes", status_code=201)
async def publicar_mensaje(
    foro_id: uuid.UUID,
    data: MensajeForoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    # Verificar que el foro existe y está activo
    f = await db.execute(text(
        "SELECT id, es_moderado FROM ades_foros WHERE id = :id AND is_active"
    ), {"id": str(foro_id)})
    foro = f.fetchone()
    if not foro:
        raise HTTPException(status_code=404, detail="Foro no encontrado")

    estado = "PENDIENTE" if foro._mapping["es_moderado"] else "PUBLICADO"

    r = await db.execute(text("""
        INSERT INTO ades_mensajes_foro
          (foro_id, asunto, contenido, adjunto_url, estado,
           autor_id, usuario_creacion, usuario_modificacion)
        VALUES (:fid, :asunto, :cont, :adj, :estado,
                :autor, :uname, :uname)
        RETURNING id
    """), {
        "fid": str(foro_id), "asunto": data.asunto, "cont": data.contenido,
        "adj": data.adjunto_url, "estado": estado,
        "autor": str(user.db_id) if user.db_id else None, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "estado": estado, "message": "Mensaje publicado"}


# ── CO-022: Respuestas encadenadas ────────────────────────────────────────────

@router.post("/{foro_id}/mensajes/{mensaje_id}/responder", status_code=201)
async def responder_mensaje(
    foro_id: uuid.UUID,
    mensaje_id: uuid.UUID,
    data: RespuestaForoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    m = await db.execute(text(
        "SELECT id FROM ades_mensajes_foro WHERE id = :id AND foro_id = :fid AND is_active"
    ), {"id": str(mensaje_id), "fid": str(foro_id)})
    if not m.fetchone():
        raise HTTPException(status_code=404, detail="Mensaje no encontrado")

    r = await db.execute(text("""
        INSERT INTO ades_respuestas_foro
          (mensaje_id, contenido, adjunto_url, autor_id,
           usuario_creacion, usuario_modificacion)
        VALUES (:mid, :cont, :adj, :autor, :uname, :uname)
        RETURNING id
    """), {
        "mid": str(mensaje_id), "cont": data.contenido, "adj": data.adjunto_url,
        "autor": str(user.db_id) if user.db_id else None, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Respuesta publicada"}


@router.get("/{foro_id}/mensajes/{mensaje_id}/respuestas")
async def listar_respuestas(
    foro_id: uuid.UUID,
    mensaje_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT id, contenido, adjunto_url, fecha_creacion, usuario_creacion
        FROM ades_respuestas_foro
        WHERE mensaje_id = :mid AND is_active = TRUE
        ORDER BY fecha_creacion
    """), {"mid": str(mensaje_id)})
    return [dict(row._mapping) for row in r.fetchall()]


# ── CO-023: Tablón de anuncios ────────────────────────────────────────────────

@router.get("/anuncios")
async def listar_anuncios(
    plantel_id: Optional[uuid.UUID] = None,
    nivel_educativo: Optional[str] = None,
    solo_vigentes: bool = True,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["is_active = TRUE"]
    params: dict = {}
    if solo_vigentes:
        filters.append("fecha_inicio <= CURRENT_DATE")
        filters.append("(fecha_fin IS NULL OR fecha_fin >= CURRENT_DATE)")
    if plantel_id:
        filters.append("(plantel_id = :plid OR plantel_id IS NULL)"); params["plid"] = str(plantel_id)
    if nivel_educativo:
        filters.append("(nivel_educativo = :nivel OR nivel_educativo IS NULL)"); params["nivel"] = nivel_educativo

    r = await db.execute(text(f"""
        SELECT id, titulo, contenido, es_urgente, nivel_educativo,
               fecha_inicio, fecha_fin, fecha_creacion, usuario_creacion
        FROM ades_anuncios
        WHERE {" AND ".join(filters)}
        ORDER BY es_urgente DESC, fecha_creacion DESC
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/anuncios", status_code=201)
async def publicar_anuncio(
    data: AnuncioIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere Coordinador o superior")

    r = await db.execute(text("""
        INSERT INTO ades_anuncios
          (titulo, contenido, plantel_id, nivel_educativo, fecha_inicio, fecha_fin,
           es_urgente, usuario_creacion, usuario_modificacion)
        VALUES (:tit, :cont, :plid, :nivel, :fi, :ff,
                :urgente, :uname, :uname)
        RETURNING id
    """), {
        "tit": data.titulo, "cont": data.contenido,
        "plid": str(data.plantel_id) if data.plantel_id else None,
        "nivel": data.nivel_educativo,
        "fi": data.fecha_inicio, "ff": data.fecha_fin,
        "urgente": data.es_urgente, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Anuncio publicado"}


@router.patch("/mensajes/{mensaje_id}/moderar")
async def moderar_mensaje(
    mensaje_id: uuid.UUID,
    estado: str = Query(..., description="Nuevo estado: PUBLICADO, RECHAZADO, PENDIENTE"),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    """Permite a coordinadores/administradores cambiar el estado o moderar un mensaje (CO-023)."""
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere rol de Coordinador o superior para moderar contenido.")

    if estado not in ("PUBLICADO", "RECHAZADO", "PENDIENTE"):
        raise HTTPException(status_code=400, detail="Estado inválido.")

    is_active = False if estado == "RECHAZADO" else True

    r = await db.execute(text("""
        UPDATE ades_mensajes_foro
        SET estado = :estado, is_active = :is_active, usuario_modificacion = :uname, fecha_modificacion = NOW()
        WHERE id = CAST(:id AS uuid)
        RETURNING id
    """), {"estado": estado, "is_active": is_active, "id": str(mensaje_id), "uname": user.id})
    row = r.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Mensaje no encontrado.")
    await db.commit()
    return {"message": f"Mensaje moderado correctamente. Estado: {estado}"}

