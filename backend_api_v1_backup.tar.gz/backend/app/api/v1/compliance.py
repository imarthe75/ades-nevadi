"""
FASE 37 — Admin/Compliance

  AD-007  GET       /compliance/login-auditoria          — historial de logins Authentik
  AD-013  GET       /compliance/estadisticas-sistema     — estadísticas globales por plantel/nivel
  AD-014  GET       /compliance/normatividad              — catálogo de normativas vigentes
  AD-014  POST      /compliance/normatividad              — registrar normativa
  AD-017  GET/POST  /compliance/retenciones               — retenciones/compromisos alumnos
  AD-018  GET       /compliance/dashboard-directivo       — KPIs directivos
  AD-030  POST      /compliance/alerta-cumplimiento       — alerta por incumplimiento normativo
"""
from __future__ import annotations
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

router = APIRouter(prefix="/compliance", tags=["compliance"])

_NIVEL_ADMIN = 2
_NIVEL_DIRECTOR = 3


# ── Schemas ───────────────────────────────────────────────────────────────────

class NormatividadIn(BaseModel):
    nombre: str = Field(min_length=3, max_length=200)
    tipo: str  # SEP | UAEMEX | INTERNA | FEDERAL | ESTATAL
    descripcion: str
    fecha_vigencia_inicio: str
    fecha_vigencia_fin: Optional[str] = None
    url_documento: Optional[str] = None
    aplica_primaria: bool = True
    aplica_secundaria: bool = True
    aplica_preparatoria: bool = True

class RetencionIn(BaseModel):
    alumno_id: uuid.UUID
    tipo_retencion: str  # ACADEMICA | ADMINISTRATIVO | CONDUCTA | OTRO
    motivo: str = Field(min_length=5)
    fecha_inicio: str
    fecha_fin: Optional[str] = None
    acciones_requeridas: Optional[str] = None

class AlertaCumplimientoIn(BaseModel):
    tipo_alerta: str  # REPROBACION | ASISTENCIA | CONDUCTA | DOCUMENTACION | OTRO
    descripcion: str = Field(min_length=5)
    alumno_id: Optional[uuid.UUID] = None
    plantel_id: Optional[uuid.UUID] = None
    severidad: str = "MEDIA"  # BAJA | MEDIA | ALTA | CRITICA
    requiere_accion: bool = True


# ── AD-007: Historial de logins ───────────────────────────────────────────────

@router.get("/login-auditoria")
async def historial_logins(
    plantel_id: Optional[uuid.UUID] = None,
    usuario: Optional[str] = None,
    desde: Optional[str] = None,
    hasta: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(100, le=500),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin Plantel o superior")

    filters = ["1=1"]
    params: dict = {"skip": skip, "limit": limit}
    if usuario:
        filters.append("usuario_id ILIKE :uq"); params["uq"] = f"%{usuario}%"
    if desde:
        filters.append("fecha_login >= :desde"); params["desde"] = desde
    if hasta:
        filters.append("fecha_login <= :hasta"); params["hasta"] = hasta

    r = await db.execute(text(f"""
        SELECT id, usuario_id, ip_origen, user_agent,
               exitoso, motivo_fallo, fecha_login
        FROM ades_log_autenticacion
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_login DESC
        LIMIT :limit OFFSET :skip
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


# ── AD-013: Estadísticas de sistema ──────────────────────────────────────────

@router.get("/estadisticas-sistema")
async def estadisticas_sistema(
    plantel_id: Optional[uuid.UUID] = None,
    ciclo_id: Optional[uuid.UUID] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    params: dict = {}
    plantel_filter = ""
    if plantel_id:
        plantel_filter = "AND g.plantel_id = :plantel_id"
        params["plantel_id"] = str(plantel_id)

    ciclo_filter = ""
    if ciclo_id:
        ciclo_filter = "AND i.ciclo_escolar_id = :ciclo_id"
        params["ciclo_id"] = str(ciclo_id)

    # Alumnos activos
    alumnos_r = await db.execute(text(f"""
        SELECT COUNT(DISTINCT i.estudiante_id) as total_alumnos,
               COUNT(DISTINCT g.plantel_id) as planteles
        FROM ades_inscripciones i
        JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE i.is_active {plantel_filter} {ciclo_filter}
    """), params)

    # Asistencia promedio
    asist_r = await db.execute(text(f"""
        SELECT ROUND(
            100.0 * SUM(CASE WHEN a.estatus = 'PRESENTE' THEN 1 ELSE 0 END) /
            NULLIF(COUNT(a.id), 0), 2
        ) as porcentaje_asistencia
        FROM ades_asistencias a
        JOIN ades_inscripciones i ON i.id = a.inscripcion_id
        JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE i.is_active {plantel_filter} {ciclo_filter}
    """), params)

    # Calificación promedio
    calif_r = await db.execute(text(f"""
        SELECT ROUND(AVG(c.calificacion_final)::numeric, 2) as promedio_general
        FROM ades_calificaciones c
        JOIN ades_inscripciones i ON i.id = c.inscripcion_id
        JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE i.is_active {plantel_filter} {ciclo_filter}
          AND c.calificacion_final IS NOT NULL
    """), params)

    # Incidentes de conducta
    conducta_r = await db.execute(text(f"""
        SELECT COUNT(*) as total_incidentes,
               SUM(CASE WHEN tipo_incidente IN ('GRAVE','MUY_GRAVE') THEN 1 ELSE 0 END) as graves
        FROM ades_incidentes_conducta ic
        JOIN ades_inscripciones i ON i.estudiante_id = ic.alumno_id AND i.is_active
        JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE ic.is_active {plantel_filter}
    """), params)

    return {
        "alumnos": dict(alumnos_r.fetchone()._mapping),
        "asistencia": dict(asist_r.fetchone()._mapping),
        "calificaciones": dict(calif_r.fetchone()._mapping),
        "conducta": dict(conducta_r.fetchone()._mapping),
    }


# ── AD-014: Normatividad ──────────────────────────────────────────────────────

@router.get("/normatividad")
async def listar_normatividad(
    tipo: Optional[str] = None,
    vigente: bool = True,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["is_active = TRUE"]
    params: dict = {}
    if tipo:
        filters.append("tipo = :tipo"); params["tipo"] = tipo
    if vigente:
        filters.append("(fecha_vigencia_fin IS NULL OR fecha_vigencia_fin >= CURRENT_DATE)")

    r = await db.execute(text(f"""
        SELECT id, nombre, tipo, descripcion, fecha_vigencia_inicio, fecha_vigencia_fin,
               url_documento, aplica_primaria, aplica_secundaria, aplica_preparatoria
        FROM ades_normatividad
        WHERE {" AND ".join(filters)}
        ORDER BY tipo, nombre
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/normatividad", status_code=201)
async def registrar_normativa(
    data: NormatividadIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin o superior")

    r = await db.execute(text("""
        INSERT INTO ades_normatividad
          (nombre, tipo, descripcion, fecha_vigencia_inicio, fecha_vigencia_fin,
           url_documento, aplica_primaria, aplica_secundaria, aplica_preparatoria,
           usuario_creacion, usuario_modificacion)
        VALUES (:nom, :tipo, :desc, :fi, :ff, :url,
                :prim, :sec, :prep, :uname, :uname)
        RETURNING id
    """), {
        "nom": data.nombre, "tipo": data.tipo, "desc": data.descripcion,
        "fi": data.fecha_vigencia_inicio, "ff": data.fecha_vigencia_fin,
        "url": data.url_documento, "prim": data.aplica_primaria,
        "sec": data.aplica_secundaria, "prep": data.aplica_preparatoria,
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Normativa registrada"}


# ── AD-017: Retenciones ───────────────────────────────────────────────────────

@router.get("/retenciones")
async def listar_retenciones(
    plantel_id: Optional[uuid.UUID] = None,
    tipo: Optional[str] = None,
    activas: bool = True,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["1=1"]
    params: dict = {"skip": skip, "limit": limit}
    if activas:
        filters.append("r.is_active = TRUE")
        filters.append("(r.fecha_fin IS NULL OR r.fecha_fin >= CURRENT_DATE)")
    if tipo:
        filters.append("r.tipo_retencion = :tipo"); params["tipo"] = tipo
    if plantel_id:
        filters.append("g.plantel_id = :plantel"); params["plantel"] = str(plantel_id)

    r = await db.execute(text(f"""
        SELECT r.id, r.tipo_retencion, r.motivo, r.fecha_inicio, r.fecha_fin,
               r.acciones_requeridas, r.is_active,
               p.nombre || ' ' || p.apellido_paterno as alumno,
               e.numero_control, g.nombre_grupo
        FROM ades_retenciones r
        JOIN ades_estudiantes e ON e.id = r.alumno_id
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_inscripciones i ON i.estudiante_id = e.id AND i.is_active
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE {" AND ".join(filters)}
        ORDER BY r.fecha_inicio DESC
        LIMIT :limit OFFSET :skip
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/retenciones", status_code=201)
async def crear_retencion(
    data: RetencionIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        INSERT INTO ades_retenciones
          (alumno_id, tipo_retencion, motivo, fecha_inicio, fecha_fin,
           acciones_requeridas, autorizado_por, usuario_creacion, usuario_modificacion)
        VALUES (:aid, :tipo, :motivo, :fi, :ff,
                :acciones, :autor, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(data.alumno_id), "tipo": data.tipo_retencion,
        "motivo": data.motivo, "fi": data.fecha_inicio, "ff": data.fecha_fin,
        "acciones": data.acciones_requeridas,
        "autor": str(user.db_id) if user.db_id else None, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Retención registrada"}


# ── AD-018: Dashboard directivo ───────────────────────────────────────────────

@router.get("/dashboard-directivo")
async def dashboard_directivo(
    plantel_id: Optional[uuid.UUID] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    params: dict = {}
    pf = "AND g.plantel_id = :plantel_id" if plantel_id else ""
    if plantel_id:
        params["plantel_id"] = str(plantel_id)

    kpi_r = await db.execute(text(f"""
        SELECT
            COUNT(DISTINCT i.estudiante_id) as total_alumnos_activos,
            COUNT(DISTINCT i.grupo_id) as total_grupos,
            COUNT(DISTINCT g.plantel_id) as total_planteles,
            ROUND(100.0 * SUM(CASE WHEN a.estatus='PRESENTE' THEN 1 ELSE 0 END) /
                NULLIF(COUNT(a.id),0), 1) as pct_asistencia,
            ROUND(AVG(c.calificacion_final)::numeric, 2) as promedio_calificaciones,
            (SELECT COUNT(*) FROM ades_bajas b2
             JOIN ades_estudiantes e2 ON e2.id = b2.estudiante_id
             WHERE b2.is_active AND b2.tipo_baja IN ('TEMPORAL','DEFINITIVA')) as total_bajas
        FROM ades_inscripciones i
        JOIN ades_grupos g ON g.id = i.grupo_id
        LEFT JOIN ades_asistencias a ON a.inscripcion_id = i.id
        LEFT JOIN ades_calificaciones c ON c.inscripcion_id = i.id
        WHERE i.is_active {pf}
    """), params)

    return dict(kpi_r.fetchone()._mapping)


# ── AD-030: Alertas de cumplimiento ──────────────────────────────────────────

@router.post("/alerta-cumplimiento", status_code=201)
async def crear_alerta(
    data: AlertaCumplimientoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        INSERT INTO ades_alertas_cumplimiento
          (tipo_alerta, descripcion, alumno_id, plantel_id, severidad,
           requiere_accion, estado, usuario_creacion, usuario_modificacion)
        VALUES (:tipo, :desc, :aid, :plid, :sev,
                :req, 'PENDIENTE', :uname, :uname)
        RETURNING id
    """), {
        "tipo": data.tipo_alerta, "desc": data.descripcion,
        "aid": str(data.alumno_id) if data.alumno_id else None,
        "plid": str(data.plantel_id) if data.plantel_id else None,
        "sev": data.severidad, "req": data.requiere_accion, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Alerta de cumplimiento registrada"}


@router.get("/alerta-cumplimiento")
async def listar_alertas(
    plantel_id: Optional[uuid.UUID] = None,
    severidad: Optional[str] = None,
    estado: str = "PENDIENTE",
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["estado = :estado"]
    params: dict = {"estado": estado, "skip": skip, "limit": limit}
    if plantel_id:
        filters.append("plantel_id = :plantel"); params["plantel"] = str(plantel_id)
    if severidad:
        filters.append("severidad = :sev"); params["sev"] = severidad

    r = await db.execute(text(f"""
        SELECT id, tipo_alerta, descripcion, severidad, estado,
               requiere_accion, fecha_creacion, usuario_creacion
        FROM ades_alertas_cumplimiento
        WHERE {" AND ".join(filters)}
        ORDER BY CASE severidad WHEN 'CRITICA' THEN 1 WHEN 'ALTA' THEN 2 WHEN 'MEDIA' THEN 3 ELSE 4 END,
                 fecha_creacion DESC
        LIMIT :limit OFFSET :skip
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]
