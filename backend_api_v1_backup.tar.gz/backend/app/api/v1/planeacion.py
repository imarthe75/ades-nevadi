"""
/planeacion — Planeación de clases y avance del plan de estudios.

  GET  /planeacion/temas              — temas del plan con estado (pendiente/planeado/impartido)
  GET  /planeacion/cobertura/{gid}    — % cobertura curricular por materia del grupo
  GET  /planeacion/clases             — entradas de planeación por grupo/materia
  POST /planeacion/clases             — crear entrada de planeación para un tema
  POST /planeacion/clases/{id}/completar — marcar tema como impartido
  DELETE /planeacion/clases/{id}      — baja lógica
"""
from __future__ import annotations

import datetime
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_current_user

router = APIRouter(prefix="/planeacion", tags=["planeacion"])


# ── schemas ───────────────────────────────────────────────────────────────────

class PlaneacionCreate(BaseModel):
    grupo_id: UUID
    tema_id: UUID
    fecha_planeada: datetime.date
    descripcion_actividades: Optional[str] = None
    recursos_didacticos: Optional[str] = None


class CompletarAvance(BaseModel):
    clase_id: Optional[UUID] = None
    fecha_ejecucion: datetime.date
    comentarios_profesor: Optional[str] = None


# ── endpoints ─────────────────────────────────────────────────────────────────

@router.get("/temas")
async def temas_con_estado(
    grupo_id: UUID,
    materia_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """
    Devuelve los temas del plan de estudios del grupo con su estado:
    IMPARTIDO / PLANEADO / PENDIENTE.
    """
    filters = ["g.id = :grupo_id::uuid", "t.is_active = TRUE"]
    params: dict = {"grupo_id": str(grupo_id)}

    if materia_id:
        filters.append("t.materia_id = :materia_id::uuid")
        params["materia_id"] = str(materia_id)

    where = " AND ".join(filters)

    rows = await db.execute(text(f"""
        SELECT
            t.id          AS tema_id,
            t.nombre_tema,
            t.descripcion AS descripcion_tema,
            t.orden,
            t.periodo_sugerido,
            m.id          AS materia_id,
            m.nombre_materia,
            pc.id         AS planeacion_id,
            pc.fecha_planeada,
            pc.descripcion_actividades,
            av.id         AS avance_id,
            av.fecha_ejecucion,
            av.es_completado,
            av.comentarios_profesor,
            CASE
                WHEN av.es_completado = TRUE THEN 'IMPARTIDO'
                WHEN pc.id IS NOT NULL       THEN 'PLANEADO'
                ELSE                              'PENDIENTE'
            END           AS estado
        FROM ades_grupos g
        JOIN ades_grados gr         ON gr.id = g.grado_id
        JOIN ades_materias_plan mp  ON mp.grado_id = gr.id
            AND mp.ciclo_escolar_id = g.ciclo_escolar_id
            AND mp.is_active = TRUE
        JOIN ades_materias m        ON m.id = mp.materia_id
        JOIN ades_temas t           ON t.materia_id = m.id
            AND (t.grado_id IS NULL OR t.grado_id = gr.id)
            AND t.is_active = TRUE
        LEFT JOIN ades_planeacion_clases pc
            ON pc.tema_id = t.id AND pc.grupo_id = g.id AND pc.is_active = TRUE
        LEFT JOIN ades_avance_planificacion av
            ON av.planeacion_clase_id = pc.id AND av.is_active = TRUE
        WHERE {where}
        ORDER BY m.nombre_materia, t.orden
    """), params)

    return rows.mappings().all()


@router.get("/cobertura/{grupo_id}")
async def cobertura_grupo(
    grupo_id: UUID,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """Porcentaje de cobertura curricular por materia para el grupo."""
    rows = await db.execute(text("""
        SELECT
            m.id          AS materia_id,
            m.nombre_materia,
            COUNT(t.id)                                               AS total_temas,
            COUNT(av.id) FILTER (WHERE av.es_completado = TRUE)       AS temas_impartidos,
            COUNT(pc.id) FILTER (WHERE av.id IS NULL)                 AS temas_planeados,
            ROUND(
                COUNT(av.id) FILTER (WHERE av.es_completado = TRUE)::numeric
                / NULLIF(COUNT(t.id), 0) * 100, 1
            )                                                         AS pct_cobertura
        FROM ades_grupos g
        JOIN ades_grados gr        ON gr.id = g.grado_id
        JOIN ades_materias_plan mp ON mp.grado_id = gr.id
            AND mp.ciclo_escolar_id = g.ciclo_escolar_id
            AND mp.is_active = TRUE
        JOIN ades_materias m       ON m.id = mp.materia_id
        JOIN ades_temas t          ON t.materia_id = m.id
            AND (t.grado_id IS NULL OR t.grado_id = gr.id)
            AND t.is_active = TRUE
        LEFT JOIN ades_planeacion_clases pc
            ON pc.tema_id = t.id AND pc.grupo_id = g.id AND pc.is_active = TRUE
        LEFT JOIN ades_avance_planificacion av
            ON av.planeacion_clase_id = pc.id AND av.is_active = TRUE
        WHERE g.id = :grupo_id::uuid
        GROUP BY m.id, m.nombre_materia
        ORDER BY m.nombre_materia
    """), {"grupo_id": str(grupo_id)})
    return rows.mappings().all()


@router.get("/clases")
async def listar_planeacion(
    grupo_id: UUID,
    materia_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    filters = ["pc.grupo_id = :grupo_id::uuid", "pc.is_active = TRUE"]
    params: dict = {"grupo_id": str(grupo_id)}

    if materia_id:
        filters.append("t.materia_id = :materia_id::uuid")
        params["materia_id"] = str(materia_id)

    where = " AND ".join(filters)
    rows = await db.execute(text(f"""
        SELECT
            pc.id, pc.fecha_planeada,
            pc.descripcion_actividades, pc.recursos_didacticos,
            t.id AS tema_id, t.nombre_tema, t.orden,
            m.nombre_materia,
            av.es_completado, av.fecha_ejecucion, av.comentarios_profesor
        FROM ades_planeacion_clases pc
        JOIN ades_temas t    ON t.id = pc.tema_id
        JOIN ades_materias m ON m.id = t.materia_id
        LEFT JOIN ades_avance_planificacion av
            ON av.planeacion_clase_id = pc.id AND av.is_active = TRUE
        WHERE {where}
        ORDER BY pc.fecha_planeada, m.nombre_materia, t.orden
    """), params)
    return rows.mappings().all()


@router.post("/clases", status_code=201)
async def crear_planeacion(
    body: PlaneacionCreate,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    row = await db.execute(text("""
        INSERT INTO ades_planeacion_clases
            (grupo_id, tema_id, fecha_planeada, descripcion_actividades, recursos_didacticos)
        VALUES
            (:grupo_id::uuid, :tema_id::uuid, :fecha, :descripcion, :recursos)
        ON CONFLICT DO NOTHING
        RETURNING id, tema_id, fecha_planeada
    """), {
        "grupo_id":    str(body.grupo_id),
        "tema_id":     str(body.tema_id),
        "fecha":       body.fecha_planeada,
        "descripcion": body.descripcion_actividades,
        "recursos":    body.recursos_didacticos,
    })
    await db.commit()
    result = row.mappings().first()
    if not result:
        return {"ok": True, "mensaje": "Ya existía una planeación para este tema/grupo"}
    return result


@router.post("/clases/{planeacion_id}/completar")
async def completar_tema(
    planeacion_id: UUID,
    body: CompletarAvance,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """Registra que el tema fue efectivamente impartido en clase."""
    row = await db.execute(text("""
        INSERT INTO ades_avance_planificacion
            (planeacion_clase_id, clase_id, fecha_ejecucion, es_completado, comentarios_profesor)
        VALUES
            (:pc_id::uuid, :clase_id, :fecha, TRUE, :comentarios)
        ON CONFLICT DO NOTHING
        RETURNING id, es_completado, fecha_ejecucion
    """), {
        "pc_id":       str(planeacion_id),
        "clase_id":    str(body.clase_id) if body.clase_id else None,
        "fecha":       body.fecha_ejecucion,
        "comentarios": body.comentarios_profesor,
    })
    await db.commit()
    return row.mappings().first() or {"ok": True, "mensaje": "Ya registrado"}


@router.delete("/clases/{planeacion_id}", status_code=204)
async def eliminar_planeacion(
    planeacion_id: UUID,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    await db.execute(text("""
        UPDATE ades_planeacion_clases SET is_active = FALSE WHERE id = :id::uuid
    """), {"id": str(planeacion_id)})
    await db.commit()


# ── OA-011: Alertas de rezago curricular (<80% temas cubiertos) ──────────────
@router.get("/alertas-rezago/{ciclo_id}")
async def alertas_rezago(
    ciclo_id: UUID,
    umbral_pct: float = 80.0,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """OA-011: Grupos/materias con menos del umbral% de temas impartidos."""
    rows = await db.execute(text("""
        SELECT
            g.id                   AS grupo_id,
            g.nombre_grupo,
            m.id                   AS materia_id,
            m.nombre_materia,
            COUNT(t.id)            AS total_temas,
            COUNT(pc.id) FILTER (WHERE pc.estado = 'IMPARTIDO') AS temas_impartidos,
            ROUND(
                COUNT(pc.id) FILTER (WHERE pc.estado = 'IMPARTIDO') * 100.0
                / NULLIF(COUNT(t.id), 0), 1
            ) AS pct_cubierto
        FROM ades_grupos g
        JOIN ades_grados gr          ON gr.id = g.grado_id
        JOIN ades_materias_grado mg  ON mg.grado_id = gr.id AND mg.is_active = TRUE
        JOIN ades_materias m         ON m.id = mg.materia_id
        LEFT JOIN ades_temas t       ON t.materia_id = m.id AND t.is_active = TRUE
        LEFT JOIN ades_planeacion_clases pc
               ON pc.grupo_id = g.id AND pc.materia_id = m.id AND pc.is_active = TRUE
        WHERE g.ciclo_escolar_id = :cid AND g.is_active = TRUE
        GROUP BY g.id, g.nombre_grupo, m.id, m.nombre_materia
        HAVING COUNT(t.id) > 0
           AND (COUNT(pc.id) FILTER (WHERE pc.estado = 'IMPARTIDO') * 100.0
                / NULLIF(COUNT(t.id), 0)) < :umbral
        ORDER BY pct_cubierto ASC, g.nombre_grupo, m.nombre_materia
    """), {"cid": str(ciclo_id), "umbral": umbral_pct})

    alertas = [dict(r) for r in rows.mappings().all()]
    return {
        "ciclo_id":      str(ciclo_id),
        "umbral_pct":    umbral_pct,
        "total_alertas": len(alertas),
        "alertas":       alertas,
    }


# ── Plan de trabajo semanal ───────────────────────────────────────────────────
@router.get("/semana/{grupo_id}")
async def plan_semana(
    grupo_id: UUID,
    fecha_inicio: datetime.date,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """
    Devuelve los temas planeados para la semana que inicia en fecha_inicio (lunes).
    Si no hay planeación explícita, sugiere los próximos temas pendientes por materia.
    """
    fecha_fin = fecha_inicio + datetime.timedelta(days=6)

    rows = await db.execute(text("""
        SELECT
            pc.id               AS planeacion_id,
            pc.fecha_planeada,
            t.id                AS tema_id,
            t.nombre_tema,
            t.orden,
            m.id                AS materia_id,
            m.nombre_materia,
            av.es_completado,
            av.fecha_ejecucion,
            CASE WHEN av.es_completado = TRUE THEN 'IMPARTIDO'
                 WHEN pc.id IS NOT NULL        THEN 'PLANEADO'
                 ELSE                               'PENDIENTE'
            END AS estado
        FROM ades_planeacion_clases pc
        JOIN ades_temas t    ON t.id = pc.tema_id
        JOIN ades_materias m ON m.id = t.materia_id
        LEFT JOIN ades_avance_planificacion av
               ON av.planeacion_clase_id = pc.id AND av.is_active = TRUE
        WHERE pc.grupo_id = :grupo_id::uuid
          AND pc.is_active = TRUE
          AND pc.fecha_planeada BETWEEN :fi AND :ff
        ORDER BY pc.fecha_planeada, m.nombre_materia, t.orden
    """), {"grupo_id": str(grupo_id), "fi": fecha_inicio, "ff": fecha_fin})

    planeados = [dict(r) for r in rows.mappings().all()]

    # Sugerir próximos temas pendientes por materia (para días sin planeación)
    sugerencias_rows = await db.execute(text("""
        WITH impartidos AS (
            SELECT t.id AS tema_id, t.materia_id
            FROM ades_planeacion_clases pc
            JOIN ades_temas t ON t.id = pc.tema_id
            JOIN ades_avance_planificacion av
                 ON av.planeacion_clase_id = pc.id AND av.es_completado = TRUE AND av.is_active = TRUE
            WHERE pc.grupo_id = :grupo_id::uuid AND pc.is_active = TRUE
        ),
        planeados_ya AS (
            SELECT tema_id FROM ades_planeacion_clases
            WHERE grupo_id = :grupo_id::uuid AND is_active = TRUE
        )
        SELECT
            t.id        AS tema_id,
            t.nombre_tema,
            t.orden,
            m.id        AS materia_id,
            m.nombre_materia,
            ROW_NUMBER() OVER (PARTITION BY m.id ORDER BY t.orden) AS rn
        FROM ades_grupos g
        JOIN ades_grados gr         ON gr.id = g.grado_id
        JOIN ades_materias_plan mp  ON mp.grado_id = gr.id
            AND mp.ciclo_escolar_id = g.ciclo_escolar_id AND mp.is_active = TRUE
        JOIN ades_materias m        ON m.id = mp.materia_id
        JOIN ades_temas t           ON t.materia_id = m.id
            AND (t.grado_id IS NULL OR t.grado_id = gr.id) AND t.is_active = TRUE
        WHERE g.id = :grupo_id::uuid
          AND t.id NOT IN (SELECT tema_id FROM impartidos)
          AND t.id NOT IN (SELECT tema_id FROM planeados_ya)
    """), {"grupo_id": str(grupo_id)})

    sugerencias = [dict(r) for r in sugerencias_rows.mappings().all() if r["rn"] <= 2]

    return {
        "grupo_id":   str(grupo_id),
        "semana":     {"inicio": fecha_inicio.isoformat(), "fin": fecha_fin.isoformat()},
        "planeados":  planeados,
        "sugerencias": sugerencias,
    }


# ── Insights académicos del gradebook ────────────────────────────────────────
@router.get("/insights/{grupo_id}")
async def insights_grupo(
    grupo_id: UUID,
    db: AsyncSession = Depends(get_db),
    _user: dict = Depends(get_current_user),
):
    """
    Dashboard de insights: cobertura del temario, avance de planeación,
    tareas vinculadas a temas y distribución de calificaciones.
    """
    # Cobertura del temario por materia
    cobertura_rows = await db.execute(text("""
        SELECT
            m.id           AS materia_id,
            m.nombre_materia,
            m.tipo_materia,
            COUNT(t.id)                                                     AS total_temas,
            COUNT(av.id) FILTER (WHERE av.es_completado = TRUE)             AS temas_impartidos,
            COUNT(pc.id) FILTER (WHERE av.id IS NULL OR av.es_completado = FALSE) AS temas_planeados,
            COUNT(t.id) FILTER (WHERE pc.id IS NULL)                        AS temas_pendientes,
            COALESCE(ROUND(
                COUNT(av.id) FILTER (WHERE av.es_completado = TRUE)::numeric
                / NULLIF(COUNT(t.id), 0) * 100, 1
            ), 0) AS pct_cobertura
        FROM ades_grupos g
        JOIN ades_grados gr        ON gr.id = g.grado_id
        JOIN ades_materias_plan mp ON mp.grado_id = gr.id
            AND mp.ciclo_escolar_id = g.ciclo_escolar_id AND mp.is_active = TRUE
        JOIN ades_materias m       ON m.id = mp.materia_id
        JOIN ades_temas t          ON t.materia_id = m.id
            AND (t.grado_id IS NULL OR t.grado_id = gr.id) AND t.is_active = TRUE
        LEFT JOIN ades_planeacion_clases pc
               ON pc.tema_id = t.id AND pc.grupo_id = g.id AND pc.is_active = TRUE
        LEFT JOIN ades_avance_planificacion av
               ON av.planeacion_clase_id = pc.id AND av.is_active = TRUE
        WHERE g.id = :grupo_id::uuid
        GROUP BY m.id, m.nombre_materia, m.tipo_materia
        ORDER BY pct_cobertura ASC, m.nombre_materia
    """), {"grupo_id": str(grupo_id)})

    cobertura = [dict(r) for r in cobertura_rows.mappings().all()]

    # Tareas vinculadas vs. sin tema
    tareas_rows = await db.execute(text("""
        SELECT
            COUNT(*)                               AS total_tareas,
            COUNT(*) FILTER (WHERE tema_id IS NOT NULL) AS tareas_con_tema,
            COUNT(*) FILTER (WHERE tema_id IS NULL)     AS tareas_sin_tema,
            COALESCE(ROUND(
                COUNT(*) FILTER (WHERE tema_id IS NOT NULL)::numeric
                / NULLIF(COUNT(*), 0) * 100, 1
            ), 0) AS pct_vinculadas
        FROM ades_tareas
        WHERE grupo_id = :grupo_id::uuid AND is_active = TRUE
    """), {"grupo_id": str(grupo_id)})

    tareas_stats = dict((tareas_rows.mappings().first() or {}))

    # Distribución de calificaciones (promedio por materia)
    cal_rows = await db.execute(text("""
        SELECT
            m.nombre_materia,
            ROUND(AVG(cp.calificacion_final)::numeric, 2) AS promedio,
            COUNT(DISTINCT cp.alumno_id)                  AS alumnos_evaluados,
            COUNT(DISTINCT cp.alumno_id) FILTER (WHERE cp.calificacion_final < 6) AS en_riesgo
        FROM ades_calificaciones_periodo cp
        JOIN ades_materias m ON m.id = cp.materia_id
        WHERE cp.grupo_id = :grupo_id::uuid AND cp.is_active = TRUE
        GROUP BY m.id, m.nombre_materia
        ORDER BY promedio ASC
    """), {"grupo_id": str(grupo_id)})

    calificaciones = [dict(r) for r in cal_rows.mappings().all()]

    # Resumen global
    total_temas = sum(r["total_temas"] for r in cobertura)
    total_impartidos = sum(r["temas_impartidos"] for r in cobertura)
    pct_global = round(total_impartidos * 100 / total_temas, 1) if total_temas else 0

    return {
        "grupo_id":   str(grupo_id),
        "resumen": {
            "total_temas":      total_temas,
            "temas_impartidos": total_impartidos,
            "pct_cobertura":    pct_global,
            "estado":           "CRITICO" if pct_global < 40 else ("ALERTA" if pct_global < 70 else "OK"),
        },
        "cobertura_por_materia": cobertura,
        "tareas":    tareas_stats,
        "calificaciones": calificaciones,
    }
