import uuid
from datetime import date
from io import BytesIO
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel
from jinja2 import Environment, FileSystemLoader

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser
from app.core.config import settings

router = APIRouter(prefix="/cierre-ciclo", tags=["cierre-ciclo"])

_TEMPLATES_DIR = Path(__file__).parent.parent.parent / "templates" / "actas"

class CierreCicloRequest(BaseModel):
    ciclo_destino_id: uuid.UUID | None = None

def _get_jinja():
    if not _TEMPLATES_DIR.exists():
        _TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
    return Environment(loader=FileSystemLoader(str(_TEMPLATES_DIR)), autoescape=True)

async def _obtener_datos_acta(ciclo_id: uuid.UUID, db: AsyncSession):
    # Obtener indicadores de la vista v_indicadores_cierre_ciclo
    res = await db.execute(
        text("SELECT * FROM v_indicadores_cierre_ciclo WHERE ciclo_escolar_id = :cid"),
        {"cid": ciclo_id}
    )
    row = res.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="No se encontraron datos para el ciclo escolar especificado.")
    
    # Obtener nombre de la institución de parámetros del sistema
    res_inst = await db.execute(
        text("SELECT valor FROM ades_parametros_sistema WHERE clave = 'NOMBRE_INSTITUCION'")
    )
    institucion = res_inst.scalar_one_or_none() or "Instituto Nevadi"

    return dict(row), institucion

@router.get("/{ciclo_id}/indicadores")
async def obtener_indicadores(
    ciclo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    """Obtiene los indicadores agregados del ciclo escolar para el cierre."""
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Acceso denegado.")
    datos, institucion = await _obtener_datos_acta(ciclo_id, db)
    return datos

@router.post("/{ciclo_id}/acta-inicio")
async def acta_inicio(
    ciclo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    """Genera el PDF WeasyPrint del acta de inicio de ciclo escolar."""
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Acceso denegado.")

    datos, institucion = await _obtener_datos_acta(ciclo_id, db)
    
    ctx = {
        "institucion": institucion,
        "nombre_ciclo": datos["nombre_ciclo"],
        "nombre_nivel": datos["nombre_nivel"],
        "fecha_inicio": datos["fecha_inicio"].strftime("%d/%m/%Y"),
        "matricula_total": datos["matricula_total"],
        "total_docentes": datos["total_docentes"],
        "fecha_generacion": date.today().strftime("%d/%m/%Y"),
        "usuario_generacion": ades_user.nombre_usuario,
    }

    template = _get_jinja().get_template("acta_inicio.html")
    html_str = template.render(**ctx)

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html_str, base_url=str(_TEMPLATES_DIR)).write_pdf()
    except ImportError:
        raise HTTPException(status_code=503, detail="WeasyPrint no disponible en el servidor.")

    filename = f"acta_inicio_{datos['nombre_ciclo']}_{datos['nombre_nivel']}.pdf"
    return StreamingResponse(
        BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

@router.post("/{ciclo_id}/acta-cierre")
async def acta_cierre(
    ciclo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    """Genera el PDF WeasyPrint del acta de cierre de ciclo escolar."""
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Acceso denegado.")

    datos, institucion = await _obtener_datos_acta(ciclo_id, db)
    
    ctx = {
        "institucion": institucion,
        "nombre_ciclo": datos["nombre_ciclo"],
        "nombre_nivel": datos["nombre_nivel"],
        "fecha_fin": datos["fecha_fin"].strftime("%d/%m/%Y"),
        "matricula_total": datos["matricula_total"],
        "promedio_general": datos["promedio_general"],
        "tasa_aprobacion": datos["tasa_aprobacion"],
        "total_bajas": datos["total_bajas"],
        "total_alumnos_activos": datos["total_alumnos_activos"],
        "fecha_generacion": date.today().strftime("%d/%m/%Y"),
        "usuario_generacion": ades_user.nombre_usuario,
    }

    template = _get_jinja().get_template("acta_cierre.html")
    html_str = template.render(**ctx)

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html_str, base_url=str(_TEMPLATES_DIR)).write_pdf()
    except ImportError:
        raise HTTPException(status_code=503, detail="WeasyPrint no disponible en el servidor.")

    filename = f"acta_cierre_{datos['nombre_ciclo']}_{datos['nombre_nivel']}.pdf"
    return StreamingResponse(
        BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

@router.post("/{ciclo_id}/ejecutar")
async def ejecutar_cierre_ciclo(
    ciclo_id: uuid.UUID,
    payload: CierreCicloRequest,
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    """Cierra el ciclo escolar y realiza la promoción si se especifica un ciclo destino."""
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores o directores pueden realizar el cierre de ciclo.")

    # Verificar que el ciclo existe
    res = await db.execute(
        text("SELECT id, estado FROM ades_ciclos_escolares WHERE id = :cid AND is_active = TRUE"),
        {"cid": ciclo_id}
    )
    ciclo = res.first()
    if not ciclo:
        raise HTTPException(status_code=404, detail="Ciclo escolar no encontrado.")
    
    if ciclo.estado == "CERRADO":
        raise HTTPException(status_code=400, detail="El ciclo escolar ya se encuentra cerrado.")

    # Cerrar ciclo origen
    await db.execute(
        text("UPDATE ades_ciclos_escolares SET estado = 'CERRADO', es_vigente = FALSE, fecha_modificacion = now() WHERE id = :cid"),
        {"cid": ciclo_id}
    )

    resultado_promo = None
    if payload.ciclo_destino_id:
        try:
            promo_res = await db.execute(
                text("SELECT cerrar_ciclo_y_promover(:origen::uuid, :destino::uuid, :usuario)"),
                {
                    "origen": str(ciclo_id),
                    "destino": str(payload.ciclo_destino_id),
                    "usuario": str(ades_user.usuario_id),
                }
            )
            resultado_promo = promo_res.scalar_one()
        except Exception as e:
            await db.rollback()
            raise HTTPException(status_code=500, detail=f"Error en promoción de alumnos: {e}")

    await db.commit()
    return {
        "ok": True,
        "message": "Ciclo escolar cerrado exitosamente.",
        "resultado_promocion": resultado_promo
    }
