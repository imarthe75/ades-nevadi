"""
FASE 33 — Evaluación Avanzada

  EV-012  GET/POST  /evaluacion-avanzada/escalas-cualitativas     — catálogo de escalas SEP/UAEMEX
  EV-014  POST      /evaluacion-avanzada/actas-sep/{grupo_id}     — generar acta SEP (trigger Carbone)
  EV-017  PATCH     /evaluacion-avanzada/observaciones/{alumno_id}— observaciones pedagógicas
  EV-024  GET/POST  /evaluacion-avanzada/nee                      — necesidades educativas especiales
  EV-025  POST      /evaluacion-avanzada/asignacion-aula-hora     — asignación aula/horario puntual
"""
from __future__ import annotations
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

router = APIRouter(prefix="/evaluacion-avanzada", tags=["evaluacion-avanzada"])

_NIVEL_DOCENTE = 4


# ── Schemas ───────────────────────────────────────────────────────────────────

class EscalaCualitativaIn(BaseModel):
    nombre: str = Field(min_length=3, max_length=80)
    nivel_educativo: str  # PRIMARIA | SECUNDARIA | PREPARATORIA
    descripcion: Optional[str] = None
    valores: list[dict]  # [{valor, descripcion, rango_min, rango_max}]

class ObservacionPedagogicaIn(BaseModel):
    observacion: str = Field(min_length=5)
    periodo: Optional[str] = None
    tipo: Optional[str] = "GENERAL"  # GENERAL | ACADEMICA | CONDUCTUAL | NEE

class NEEIn(BaseModel):
    alumno_id: uuid.UUID
    tipo_nee: str  # DISCAPACIDAD | APTITUDES | PROBLEMAS_APRENDIZAJE | OTRO
    descripcion: str = Field(min_length=5)
    apoyos_requeridos: Optional[str] = None
    fecha_deteccion: Optional[str] = None
    profesional_detecta: Optional[str] = None
    activa: bool = True

class AsignacionAulaHoraIn(BaseModel):
    clase_id: uuid.UUID
    aula_id: uuid.UUID
    fecha: str
    hora_inicio: str
    hora_fin: str
    observaciones: Optional[str] = None


# ── EV-012: Escalas Cualitativas ─────────────────────────────────────────────

@router.get("/escalas-cualitativas")
async def listar_escalas(
    nivel_educativo: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["1=1"]
    params: dict = {}
    if nivel_educativo:
        filters.append("nivel_educativo = :nivel"); params["nivel"] = nivel_educativo

    r = await db.execute(text(f"""
        SELECT id, nombre, nivel_educativo, descripcion, is_active, fecha_creacion
        FROM ades_escalas_evaluacion
        WHERE {" AND ".join(filters)}
        ORDER BY nivel_educativo, nombre
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/escalas-cualitativas", status_code=201)
async def crear_escala(
    data: EscalaCualitativaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere nivel Coordinador o superior")

    import json
    r = await db.execute(text("""
        INSERT INTO ades_escalas_evaluacion
          (nombre, nivel_educativo, descripcion, valores_json, usuario_creacion, usuario_modificacion)
        VALUES (:nom, :nivel, :desc, :vals::jsonb, :uname, :uname)
        RETURNING id
    """), {
        "nom": data.nombre, "nivel": data.nivel_educativo,
        "desc": data.descripcion, "vals": json.dumps(data.valores),
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Escala creada"}


# ── EV-014: Actas SEP ─────────────────────────────────────────────────────────

@router.post("/actas-sep/{grupo_id}")
async def generar_acta_sep(
    grupo_id: uuid.UUID,
    periodo: str = Query(..., description="1B, 2B, 3B, FIN"),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere Coordinador o superior")

    # Verificar que el grupo existe
    g = await db.execute(text(
        "SELECT id, nombre_grupo FROM ades_grupos WHERE id = :gid AND is_active"
    ), {"gid": str(grupo_id)})
    grupo = g.fetchone()
    if not grupo:
        raise HTTPException(status_code=404, detail="Grupo no encontrado")

    # Obtener calificaciones consolidadas
    r = await db.execute(text("""
        SELECT
            p.nombre || ' ' || p.apellido_paterno AS alumno,
            e.numero_control,
            m.nombre_materia,
            COALESCE(c.calificacion_final, 0) as calificacion,
            COALESCE(c.asistencia_porcentaje, 0) as asistencia
        FROM ades_inscripciones i
        JOIN ades_estudiantes e ON e.id = i.estudiante_id
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_calificaciones c ON c.inscripcion_id = i.id
        LEFT JOIN ades_materias m ON m.id = c.materia_id
        WHERE i.grupo_id = :gid AND i.is_active
        ORDER BY p.apellido_paterno, p.nombre, m.nombre_materia
    """), {"gid": str(grupo_id)})
    registros = [dict(row._mapping) for row in r.fetchall()]

    return {
        "grupo": dict(grupo._mapping),
        "periodo": periodo,
        "registros": registros,
        "total_alumnos": len(set(r["numero_control"] for r in registros)),
        "message": "Datos para acta SEP generados. Use /api/v1/carbone para renderizar PDF.",
    }


# ── EV-017: Observaciones Pedagógicas ────────────────────────────────────────

@router.patch("/observaciones/{alumno_id}", status_code=200)
async def guardar_observaciones(
    alumno_id: uuid.UUID,
    data: ObservacionPedagogicaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DOCENTE:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    await db.execute(text("""
        INSERT INTO ades_observaciones_pedagogicas
          (alumno_id, observacion, periodo, tipo, autor_id, usuario_creacion, usuario_modificacion)
        VALUES (:aid, :obs, :periodo, :tipo, :autor, :uname, :uname)
    """), {
        "aid": str(alumno_id), "obs": data.observacion,
        "periodo": data.periodo, "tipo": data.tipo,
        "autor": str(user.db_id) if user.db_id else None,
        "uname": user.id,
    })
    await db.commit()
    return {"message": "Observación pedagógica registrada"}


@router.get("/observaciones/{alumno_id}")
async def listar_observaciones(
    alumno_id: uuid.UUID,
    tipo: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["alumno_id = :aid"]
    params: dict = {"aid": str(alumno_id)}
    if tipo:
        filters.append("tipo = :tipo"); params["tipo"] = tipo

    r = await db.execute(text(f"""
        SELECT id, observacion, periodo, tipo, fecha_creacion,
               usuario_creacion as autor
        FROM ades_observaciones_pedagogicas
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_creacion DESC
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


# ── EV-024: NEE — Necesidades Educativas Especiales ──────────────────────────

@router.get("/nee")
async def listar_nee(
    plantel_id: Optional[uuid.UUID] = None,
    tipo_nee: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["n.activa = TRUE"]
    params: dict = {}
    if tipo_nee:
        filters.append("n.tipo_nee = :tipo"); params["tipo"] = tipo_nee
    if plantel_id:
        filters.append("g.plantel_id = :plantel"); params["plantel"] = str(plantel_id)

    r = await db.execute(text(f"""
        SELECT n.id, n.tipo_nee, n.descripcion, n.apoyos_requeridos,
               n.fecha_deteccion, n.profesional_detecta,
               p.nombre || ' ' || p.apellido_paterno as alumno,
               e.numero_control
        FROM ades_nee n
        JOIN ades_estudiantes e ON e.id = n.alumno_id
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_inscripciones i ON i.estudiante_id = e.id AND i.is_active
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        WHERE {" AND ".join(filters)}
        ORDER BY p.apellido_paterno, p.nombre
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/nee", status_code=201)
async def registrar_nee(
    data: NEEIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        INSERT INTO ades_nee
          (alumno_id, tipo_nee, descripcion, apoyos_requeridos,
           fecha_deteccion, profesional_detecta, activa, usuario_creacion, usuario_modificacion)
        VALUES (:aid, :tipo, :desc, :apoyos, :fecha, :prof, :activa, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(data.alumno_id), "tipo": data.tipo_nee,
        "desc": data.descripcion, "apoyos": data.apoyos_requeridos,
        "fecha": data.fecha_deteccion, "prof": data.profesional_detecta,
        "activa": data.activa, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "NEE registrada"}


# ── EV-025: Asignación Aula/Hora ─────────────────────────────────────────────

@router.post("/asignacion-aula-hora", status_code=201)
async def asignar_aula_hora(
    data: AsignacionAulaHoraIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    # Verificar conflicto de aula
    conflicto = await db.execute(text("""
        SELECT id FROM ades_asignaciones_aula
        WHERE aula_id = :aula AND fecha = :fecha
          AND NOT (hora_fin <= :hi OR hora_inicio >= :hf)
          AND is_active = TRUE
    """), {
        "aula": str(data.aula_id), "fecha": data.fecha,
        "hi": data.hora_inicio, "hf": data.hora_fin,
    })
    if conflicto.fetchone():
        raise HTTPException(status_code=409, detail="El aula ya está ocupada en ese horario")

    await db.execute(text("""
        INSERT INTO ades_asignaciones_aula
          (clase_id, aula_id, fecha, hora_inicio, hora_fin, observaciones,
           usuario_creacion, usuario_modificacion)
        VALUES (:cid, :aula, :fecha, :hi, :hf, :obs, :uname, :uname)
    """), {
        "cid": str(data.clase_id), "aula": str(data.aula_id),
        "fecha": data.fecha, "hi": data.hora_inicio, "hf": data.hora_fin,
        "obs": data.observaciones, "uname": user.id,
    })
    await db.commit()
    return {"message": "Aula asignada para la fecha y hora indicadas"}


@router.get("/asignacion-aula-hora")
async def consultar_asignaciones_aula(
    aula_id: Optional[uuid.UUID] = None,
    fecha: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["aa.is_active = TRUE"]
    params: dict = {}
    if aula_id:
        filters.append("aa.aula_id = :aula"); params["aula"] = str(aula_id)
    if fecha:
        filters.append("aa.fecha = :fecha"); params["fecha"] = fecha

    r = await db.execute(text(f"""
        SELECT aa.id, aa.fecha, aa.hora_inicio, aa.hora_fin, aa.observaciones,
               a.nombre_aula, a.clave_aula,
               cl.descripcion as clase_desc
        FROM ades_asignaciones_aula aa
        JOIN ades_aulas a ON a.id = aa.aula_id
        LEFT JOIN ades_clases cl ON cl.id = aa.clase_id
        WHERE {" AND ".join(filters)}
        ORDER BY aa.fecha, aa.hora_inicio
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]
