"""
/movilidad — Movilidad Estudiantil (FASE 32)

  PE-018  POST /movilidad/cambio-grupo/{estudiante_id}   — cambio de grupo dentro del plantel
  PE-019  POST /movilidad/traslado/{estudiante_id}       — traslado entre planteles
  PE-020  POST /movilidad/baja-temporal/{estudiante_id}  — baja temporal
  PE-021  POST /movilidad/baja-definitiva/{estudiante_id}— baja definitiva
  PE-022  POST /movilidad/reactivar/{estudiante_id}      — reactivación tras baja temporal
          GET  /movilidad/historial/{estudiante_id}      — historial completo de movilidad
          GET  /movilidad/bajas                          — listado de bajas (admin)
"""
from __future__ import annotations
import uuid
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

router = APIRouter(prefix="/movilidad", tags=["movilidad"])

_NIVEL_DIRECTOR = 3   # Director / Coordinador o superior


# ── Schemas ───────────────────────────────────────────────────────────────────

class CambioGrupoIn(BaseModel):
    grupo_destino_id: uuid.UUID
    motivo: str = Field(min_length=5, max_length=200)
    ciclo_escolar_id: Optional[uuid.UUID] = None

class TrasladoIn(BaseModel):
    plantel_destino_id: uuid.UUID
    grupo_destino_id: Optional[uuid.UUID] = None
    motivo: str = Field(min_length=5, max_length=200)
    plantel_destino_nombre: Optional[str] = None
    clave_ct_destino: Optional[str] = None

class BajaIn(BaseModel):
    motivo: str = Field(min_length=5)
    fecha_efectiva: date
    fecha_reingreso: Optional[date] = None
    plantel_destino: Optional[str] = None
    clave_ct_destino: Optional[str] = None
    observaciones: Optional[str] = None

class ReactivarIn(BaseModel):
    grupo_id: uuid.UUID
    ciclo_escolar_id: uuid.UUID
    observaciones: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _get_inscripcion_activa(estudiante_id: uuid.UUID, db: AsyncSession) -> dict:
    r = await db.execute(text("""
        SELECT i.id, i.grupo_id, i.ciclo_escolar_id, e.is_active as est_activo,
               g.nombre_grupo, g.plantel_id, g.capacidad_maxima,
               (SELECT COUNT(*) FROM ades_inscripciones WHERE grupo_id = i.grupo_id AND is_active) as inscritos
        FROM ades_inscripciones i
        JOIN ades_grupos g ON g.id = i.grupo_id
        JOIN ades_estudiantes e ON e.id = i.estudiante_id
        WHERE i.estudiante_id = :eid AND i.is_active = TRUE
        ORDER BY i.fecha_inscripcion DESC LIMIT 1
    """), {"eid": str(estudiante_id)})
    row = r.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="El alumno no tiene inscripción activa")
    return dict(row._mapping)


# ── PE-018: Cambio de grupo ───────────────────────────────────────────────────

@router.post("/cambio-grupo/{estudiante_id}", status_code=201)
async def cambio_grupo(
    estudiante_id: uuid.UUID,
    data: CambioGrupoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Se requiere nivel Director o superior")

    insc = await _get_inscripcion_activa(estudiante_id, db)

    # Validar grupo destino
    gd = await db.execute(text("""
        SELECT id, nombre_grupo, plantel_id, capacidad_maxima,
               (SELECT COUNT(*) FROM ades_inscripciones WHERE grupo_id = :gid AND is_active) as inscritos
        FROM ades_grupos WHERE id = :gid AND is_active = TRUE
    """), {"gid": str(data.grupo_destino_id)})
    grupo_destino = gd.fetchone()
    if not grupo_destino:
        raise HTTPException(status_code=404, detail="Grupo destino no encontrado o inactivo")
    gd_map = dict(grupo_destino._mapping)
    if gd_map["inscritos"] >= gd_map["capacidad_maxima"]:
        raise HTTPException(status_code=400, detail=f"Grupo destino lleno ({gd_map['inscritos']}/{gd_map['capacidad_maxima']})")

    # Registrar cambio
    await db.execute(text("""
        INSERT INTO ades_cambios_grupo
          (estudiante_id, inscripcion_id, grupo_origen_id, grupo_destino_id, fecha_cambio, motivo, autorizado_por_id, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :iid, :go, :gd, CURRENT_DATE, :motivo, :uid, :uname, :uname)
    """), {
        "eid": str(estudiante_id), "iid": insc["id"],
        "go": insc["grupo_id"], "gd": str(data.grupo_destino_id),
        "motivo": data.motivo, "uid": str(user.db_id) if user.db_id else None,
        "uname": user.id,
    })

    # Actualizar inscripción
    await db.execute(text("""
        UPDATE ades_inscripciones SET grupo_id = :gd, usuario_modificacion = :uname
        WHERE id = :iid
    """), {"gd": str(data.grupo_destino_id), "iid": insc["id"], "uname": user.id})

    await db.commit()
    return {"message": "Cambio de grupo registrado", "grupo_anterior": insc["nombre_grupo"], "grupo_nuevo": gd_map["nombre_grupo"]}


# ── PE-019: Traslado entre planteles ─────────────────────────────────────────

@router.post("/traslado/{estudiante_id}", status_code=201)
async def traslado_plantel(
    estudiante_id: uuid.UUID,
    data: TrasladoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Se requiere nivel Admin Plantel o superior")

    insc = await _get_inscripcion_activa(estudiante_id, db)

    # Desactivar inscripción actual
    await db.execute(text("""
        UPDATE ades_inscripciones SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :iid
    """), {"iid": insc["id"], "uname": user.id})

    # Registrar baja tipo TRASLADO
    await db.execute(text("""
        INSERT INTO ades_bajas
          (estudiante_id, inscripcion_id, tipo_baja, motivo, fecha_efectiva,
           plantel_destino, clave_ct_destino, autorizado_por_id, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :iid, 'TRASLADO', :motivo, CURRENT_DATE,
                :pdest, :clave, :uid, :uname, :uname)
    """), {
        "eid": str(estudiante_id), "iid": insc["id"],
        "motivo": data.motivo,
        "pdest": data.plantel_destino_nombre or str(data.plantel_destino_id),
        "clave": data.clave_ct_destino,
        "uid": str(user.db_id) if user.db_id else None,
        "uname": user.id,
    })

    # Si se especificó grupo destino en mismo sistema, crear nueva inscripción
    if data.grupo_destino_id:
        ciclo_r = await db.execute(text(
            "SELECT id FROM ades_ciclos_escolares WHERE es_vigente=TRUE LIMIT 1"
        ))
        ciclo_row = ciclo_r.fetchone()
        if ciclo_row:
            await db.execute(text("""
                INSERT INTO ades_inscripciones
                  (estudiante_id, grupo_id, ciclo_escolar_id, fecha_inscripcion, usuario_creacion, usuario_modificacion)
                VALUES (:eid, :gid, :cid, CURRENT_DATE, :uname, :uname)
            """), {
                "eid": str(estudiante_id), "gid": str(data.grupo_destino_id),
                "cid": str(ciclo_row._mapping["id"]), "uname": user.id,
            })

    await db.commit()
    return {"message": "Traslado registrado exitosamente"}


# ── PE-020: Baja temporal ─────────────────────────────────────────────────────

@router.post("/baja-temporal/{estudiante_id}", status_code=201)
async def baja_temporal(
    estudiante_id: uuid.UUID,
    data: BajaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Se requiere nivel Director o superior")

    insc = await _get_inscripcion_activa(estudiante_id, db)

    # Suspender inscripción (is_active = False) pero NO eliminarla
    await db.execute(text("""
        UPDATE ades_inscripciones SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :iid
    """), {"iid": insc["id"], "uname": user.id})

    # Registrar baja temporal
    await db.execute(text("""
        INSERT INTO ades_bajas
          (estudiante_id, inscripcion_id, tipo_baja, motivo, fecha_efectiva,
           fecha_reingreso, observaciones, autorizado_por_id, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :iid, 'TEMPORAL', :motivo, :fecha,
                :reingreso, :obs, :uid, :uname, :uname)
    """), {
        "eid": str(estudiante_id), "iid": insc["id"],
        "motivo": data.motivo, "fecha": data.fecha_efectiva,
        "reingreso": data.fecha_reingreso, "obs": data.observaciones,
        "uid": str(user.db_id) if user.db_id else None, "uname": user.id,
    })

    # Marcar alumno como inactivo temporalmente
    await db.execute(text("""
        UPDATE ades_estudiantes SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :eid
    """), {"eid": str(estudiante_id), "uname": user.id})

    await db.commit()
    return {"message": "Baja temporal registrada", "fecha_reingreso_estimada": str(data.fecha_reingreso) if data.fecha_reingreso else None}


# ── PE-021: Baja definitiva ───────────────────────────────────────────────────

@router.post("/baja-definitiva/{estudiante_id}", status_code=201)
async def baja_definitiva(
    estudiante_id: uuid.UUID,
    data: BajaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Se requiere nivel Admin Plantel o superior")

    insc = await _get_inscripcion_activa(estudiante_id, db)

    # Desactivar inscripción
    await db.execute(text("""
        UPDATE ades_inscripciones SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :iid
    """), {"iid": insc["id"], "uname": user.id})

    # Registrar baja definitiva
    await db.execute(text("""
        INSERT INTO ades_bajas
          (estudiante_id, inscripcion_id, tipo_baja, motivo, fecha_efectiva,
           plantel_destino, clave_ct_destino, observaciones, autorizado_por_id, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :iid, 'DEFINITIVA', :motivo, :fecha,
                :pdest, :clave, :obs, :uid, :uname, :uname)
    """), {
        "eid": str(estudiante_id), "iid": insc["id"],
        "motivo": data.motivo, "fecha": data.fecha_efectiva,
        "pdest": data.plantel_destino, "clave": data.clave_ct_destino,
        "obs": data.observaciones,
        "uid": str(user.db_id) if user.db_id else None, "uname": user.id,
    })

    # Marcar alumno como dado de baja
    await db.execute(text("""
        UPDATE ades_estudiantes SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :eid
    """), {"eid": str(estudiante_id), "uname": user.id})

    await db.commit()
    return {"message": "Baja definitiva registrada"}


# ── PE-022: Reactivación ──────────────────────────────────────────────────────

@router.post("/reactivar/{estudiante_id}", status_code=201)
async def reactivar_alumno(
    estudiante_id: uuid.UUID,
    data: ReactivarIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Se requiere nivel Director o superior")

    # Verificar que tiene baja temporal activa (is_active=False pero baja TEMPORAL)
    baja_r = await db.execute(text("""
        SELECT id FROM ades_bajas
        WHERE estudiante_id = :eid AND tipo_baja = 'TEMPORAL' AND is_active = TRUE
        ORDER BY fecha_efectiva DESC LIMIT 1
    """), {"eid": str(estudiante_id)})
    baja = baja_r.fetchone()
    if not baja:
        raise HTTPException(status_code=400, detail="El alumno no tiene baja temporal activa")

    # Reactivar alumno
    await db.execute(text("""
        UPDATE ades_estudiantes SET is_active = TRUE, usuario_modificacion = :uname WHERE id = :eid
    """), {"eid": str(estudiante_id), "uname": user.id})

    # Cerrar baja temporal
    await db.execute(text("""
        UPDATE ades_bajas SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :bid
    """), {"bid": str(baja._mapping["id"]), "uname": user.id})

    # Crear nueva inscripción
    await db.execute(text("""
        INSERT INTO ades_inscripciones
          (estudiante_id, grupo_id, ciclo_escolar_id, fecha_inscripcion, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :gid, :cid, CURRENT_DATE, :uname, :uname)
    """), {
        "eid": str(estudiante_id), "gid": str(data.grupo_id),
        "cid": str(data.ciclo_escolar_id), "uname": user.id,
    })

    await db.commit()
    return {"message": "Alumno reactivado e inscrito en nuevo grupo"}


# ── Historial de movilidad ────────────────────────────────────────────────────

@router.get("/historial/{estudiante_id}")
async def historial_movilidad(
    estudiante_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    cambios_r = await db.execute(text("""
        SELECT cg.fecha_cambio, cg.motivo,
               go.nombre_grupo as grupo_origen, gd.nombre_grupo as grupo_destino,
               'CAMBIO_GRUPO' as tipo
        FROM ades_cambios_grupo cg
        JOIN ades_grupos go ON go.id = cg.grupo_origen_id
        JOIN ades_grupos gd ON gd.id = cg.grupo_destino_id
        WHERE cg.estudiante_id = :eid
        ORDER BY cg.fecha_cambio DESC
    """), {"eid": str(estudiante_id)})

    bajas_r = await db.execute(text("""
        SELECT tipo_baja, motivo, fecha_efectiva, fecha_reingreso,
               plantel_destino, observaciones, is_active as activa
        FROM ades_bajas WHERE estudiante_id = :eid ORDER BY fecha_efectiva DESC
    """), {"eid": str(estudiante_id)})

    return {
        "cambios_grupo": [dict(r._mapping) for r in cambios_r.fetchall()],
        "bajas": [dict(r._mapping) for r in bajas_r.fetchall()],
    }


# ── Listado de bajas (administración) ────────────────────────────────────────

@router.get("/bajas")
async def listar_bajas(
    plantel_id: Optional[uuid.UUID] = None,
    tipo_baja: Optional[str] = None,
    solo_activas: bool = True,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_DIRECTOR:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["1=1"]
    params: dict = {"skip": skip, "limit": limit}

    if solo_activas:
        filters.append("b.is_active = TRUE")
    if tipo_baja:
        filters.append("b.tipo_baja = :tipo"); params["tipo"] = tipo_baja
    if plantel_id:
        filters.append("g.plantel_id = :plantel_id"); params["plantel_id"] = str(plantel_id)

    where = " AND ".join(filters)
    r = await db.execute(text(f"""
        SELECT b.id, b.tipo_baja, b.motivo, b.fecha_efectiva, b.fecha_reingreso,
               b.plantel_destino, b.is_active,
               e.numero_control, p.nombre || ' ' || p.apellido_paterno as nombre_alumno,
               g.nombre_grupo, pl.nombre_plantel
        FROM ades_bajas b
        JOIN ades_estudiantes e ON e.id = b.estudiante_id
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_inscripciones i ON i.id = b.inscripcion_id
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        LEFT JOIN ades_planteles pl ON pl.id = g.plantel_id
        WHERE {where}
        ORDER BY b.fecha_efectiva DESC
        LIMIT :limit OFFSET :skip
    """), params)

    return [dict(row._mapping) for row in r.fetchall()]
