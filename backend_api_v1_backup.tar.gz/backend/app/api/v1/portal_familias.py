"""
FASE 34 — Portal Familias

  PE-029  GET/POST  /portal-familias/tutores/{alumno_id}    — gestión de múltiples tutores
  PE-032  POST      /portal-familias/crear-usuario           — crear usuario Authentik para padre
  PE-033  POST      /portal-familias/restriccion/{tutor_id} — restricciones de acceso del tutor
          GET       /portal-familias/mis-alumnos             — alumnos vinculados al tutor autenticado
          GET       /portal-familias/resumen/{alumno_id}     — resumen académico para portal padre
"""
from __future__ import annotations
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, EmailStr
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

router = APIRouter(prefix="/portal-familias", tags=["portal-familias"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class TutorIn(BaseModel):
    persona_id: uuid.UUID
    relacion: str = Field(default="TUTOR")  # PADRE | MADRE | TUTOR | ABUELO | OTRO
    es_responsable_economico: bool = False
    es_contacto_emergencia: bool = False
    prioridad: int = Field(default=1, ge=1, le=5)
    puede_recoger: bool = True
    nivel_acceso_portal: str = "LECTURA"  # LECTURA | COMPLETO | SIN_ACCESO

class CrearUsuarioPadreIn(BaseModel):
    tutor_alumno_id: uuid.UUID
    email: str
    nombre_completo: str

class RestriccionTutorIn(BaseModel):
    puede_ver_calificaciones: bool = True
    puede_ver_asistencias: bool = True
    puede_ver_conducta: bool = True
    puede_ver_tareas: bool = True
    puede_descargar_documentos: bool = True
    puede_comunicarse_docentes: bool = True
    razon_restriccion: Optional[str] = None


# ── PE-029: Tutores múltiples ─────────────────────────────────────────────────

@router.get("/tutores/{alumno_id}")
async def listar_tutores(
    alumno_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT ta.id, ta.relacion, ta.prioridad, ta.puede_recoger,
               ta.es_responsable_economico, ta.es_contacto_emergencia,
               ta.nivel_acceso_portal, ta.is_active,
               p.nombre, p.apellido_paterno, p.apellido_materno,
               p.telefono_principal, p.email
        FROM ades_tutores_alumnos ta
        JOIN ades_personas p ON p.id = ta.persona_id
        WHERE ta.alumno_id = :aid AND ta.is_active = TRUE
        ORDER BY ta.prioridad
    """), {"aid": str(alumno_id)})
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/tutores/{alumno_id}", status_code=201)
async def agregar_tutor(
    alumno_id: uuid.UUID,
    data: TutorIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere Coordinador o superior")

    # Verificar alumno existe
    a = await db.execute(text("SELECT id FROM ades_estudiantes WHERE id = :id AND is_active"), {"id": str(alumno_id)})
    if not a.fetchone():
        raise HTTPException(status_code=404, detail="Alumno no encontrado")

    r = await db.execute(text("""
        INSERT INTO ades_tutores_alumnos
          (alumno_id, persona_id, relacion, prioridad, puede_recoger,
           es_responsable_economico, es_contacto_emergencia, nivel_acceso_portal,
           usuario_creacion, usuario_modificacion)
        VALUES (:aid, :pid, :relacion, :prior, :recoger,
                :resp_econ, :contacto, :acceso, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(alumno_id), "pid": str(data.persona_id),
        "relacion": data.relacion, "prior": data.prioridad,
        "recoger": data.puede_recoger, "resp_econ": data.es_responsable_economico,
        "contacto": data.es_contacto_emergencia, "acceso": data.nivel_acceso_portal,
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Tutor vinculado al alumno"}


@router.delete("/tutores/{tutor_alumno_id}", status_code=200)
async def desvincular_tutor(
    tutor_alumno_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Se requiere Coordinador o superior")

    await db.execute(text("""
        UPDATE ades_tutores_alumnos SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :id
    """), {"id": str(tutor_alumno_id), "uname": user.id})
    await db.commit()
    return {"message": "Tutor desvinculado"}


# ── PE-032: Crear usuario Authentik para padre ────────────────────────────────

@router.post("/crear-usuario", status_code=201)
async def crear_usuario_padre(
    data: CrearUsuarioPadreIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Se requiere Admin Plantel o superior")

    # Verificar que existe el vínculo tutor-alumno
    ta = await db.execute(text(
        "SELECT id, alumno_id FROM ades_tutores_alumnos WHERE id = :id AND is_active"
    ), {"id": str(data.tutor_alumno_id)})
    tutor_alumno = ta.fetchone()
    if not tutor_alumno:
        raise HTTPException(status_code=404, detail="Vínculo tutor-alumno no encontrado")

    # Registrar pendiente de creación en cola (Celery task)
    await db.execute(text("""
        INSERT INTO ades_tareas_sistema
          (tipo_tarea, payload_json, estado, usuario_creacion, usuario_modificacion)
        VALUES ('CREAR_USUARIO_PADRE', :payload::jsonb, 'PENDIENTE', :uname, :uname)
    """), {
        "payload": f'{{"tutor_alumno_id": "{data.tutor_alumno_id}", "email": "{data.email}", "nombre": "{data.nombre_completo}"}}',
        "uname": user.id,
    })
    await db.commit()

    return {
        "message": "Solicitud de creación de usuario encolada. Se enviará invitación al correo.",
        "email": data.email,
    }


# ── PE-033: Restricciones de acceso del tutor ────────────────────────────────

@router.post("/restriccion/{tutor_alumno_id}", status_code=200)
async def establecer_restriccion(
    tutor_alumno_id: uuid.UUID,
    data: RestriccionTutorIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Se requiere Admin Plantel o superior")

    await db.execute(text("""
        INSERT INTO ades_restricciones_tutor
          (tutor_alumno_id, puede_ver_calificaciones, puede_ver_asistencias,
           puede_ver_conducta, puede_ver_tareas, puede_descargar_documentos,
           puede_comunicarse_docentes, razon_restriccion,
           usuario_creacion, usuario_modificacion)
        VALUES (:taid, :calif, :asist, :cond, :tareas, :docs, :comunica, :razon, :uname, :uname)
        ON CONFLICT (tutor_alumno_id) DO UPDATE SET
          puede_ver_calificaciones = EXCLUDED.puede_ver_calificaciones,
          puede_ver_asistencias = EXCLUDED.puede_ver_asistencias,
          puede_ver_conducta = EXCLUDED.puede_ver_conducta,
          puede_ver_tareas = EXCLUDED.puede_ver_tareas,
          puede_descargar_documentos = EXCLUDED.puede_descargar_documentos,
          puede_comunicarse_docentes = EXCLUDED.puede_comunicarse_docentes,
          razon_restriccion = EXCLUDED.razon_restriccion,
          usuario_modificacion = EXCLUDED.usuario_modificacion
    """), {
        "taid": str(tutor_alumno_id),
        "calif": data.puede_ver_calificaciones, "asist": data.puede_ver_asistencias,
        "cond": data.puede_ver_conducta, "tareas": data.puede_ver_tareas,
        "docs": data.puede_descargar_documentos, "comunica": data.puede_comunicarse_docentes,
        "razon": data.razon_restriccion, "uname": user.id,
    })
    await db.commit()
    return {"message": "Restricciones de acceso actualizadas"}


# ── Mis alumnos (tutor autenticado) ──────────────────────────────────────────

@router.get("/mis-alumnos")
async def mis_alumnos(
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT
            e.id as alumno_id, e.numero_control,
            p.nombre, p.apellido_paterno, p.apellido_materno,
            g.nombre_grupo, pl.nombre_plantel,
            ta.relacion, ta.nivel_acceso_portal
        FROM ades_tutores_alumnos ta
        JOIN ades_personas per ON per.email = :email
        JOIN ades_personas p ON p.id = (SELECT persona_id FROM ades_estudiantes WHERE id = ta.alumno_id)
        JOIN ades_estudiantes e ON e.id = ta.alumno_id
        LEFT JOIN ades_inscripciones i ON i.estudiante_id = e.id AND i.is_active
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        LEFT JOIN ades_planteles pl ON pl.id = g.plantel_id
        WHERE ta.persona_id = per.id AND ta.is_active AND e.is_active
    """), {"email": user.email or ""})
    return [dict(row._mapping) for row in r.fetchall()]


# ── Resumen académico para portal padre ──────────────────────────────────────

@router.get("/resumen/{alumno_id}")
async def resumen_academico(
    alumno_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    # Calificaciones
    calif_r = await db.execute(text("""
        SELECT m.nombre_materia, c.calificacion_final, c.periodo
        FROM ades_calificaciones c
        JOIN ades_materias m ON m.id = c.materia_id
        JOIN ades_inscripciones i ON i.id = c.inscripcion_id
        WHERE i.estudiante_id = :aid AND i.is_active
        ORDER BY m.nombre_materia, c.periodo
    """), {"aid": str(alumno_id)})

    # Asistencias (últimas 30 clases)
    asist_r = await db.execute(text("""
        SELECT COUNT(*) as total,
               SUM(CASE WHEN estatus = 'PRESENTE' THEN 1 ELSE 0 END) as presentes,
               SUM(CASE WHEN estatus = 'FALTA' THEN 1 ELSE 0 END) as faltas,
               SUM(CASE WHEN estatus IN ('TARDE','TARDANZA') THEN 1 ELSE 0 END) as tardanzas
        FROM ades_asistencias a
        JOIN ades_inscripciones i ON i.estudiante_id = :aid AND i.is_active
        WHERE a.inscripcion_id = i.id
    """), {"aid": str(alumno_id)})

    # Conducta pendiente
    cond_r = await db.execute(text("""
        SELECT COUNT(*) as total_incidentes
        FROM ades_incidentes_conducta
        WHERE alumno_id = :aid AND is_active
    """), {"aid": str(alumno_id)})

    return {
        "calificaciones": [dict(r._mapping) for r in calif_r.fetchall()],
        "asistencias": dict(asist_r.fetchone()._mapping),
        "conducta": dict(cond_r.fetchone()._mapping),
    }
