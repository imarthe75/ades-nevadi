"""
FASE 35 — Salud Avanzada

  SB-003  GET/POST  /salud-avanzada/medicamentos/{alumno_id}       — catálogo de medicamentos
  SB-005  POST      /salud-avanzada/actas-incidente/{incidente_id} — acta formal de incidente
  SB-021  GET/POST  /salud-avanzada/psicosocial/{alumno_id}        — seguimiento psicosocial
  SB-022  GET/POST  /salud-avanzada/tutorias                        — sesiones de tutoría
"""
from __future__ import annotations
import uuid
from typing import Optional
from io import BytesIO
from pathlib import Path
from datetime import datetime
from fastapi.responses import StreamingResponse
from jinja2 import Environment, FileSystemLoader

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser

TEMPLATES_DIR = Path(__file__).parent.parent.parent / "templates" / "salud"
_jinja_env: Environment | None = None

def _get_jinja() -> Environment:
    global _jinja_env
    if _jinja_env is None:
        _jinja_env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)), autoescape=True)
    return _jinja_env


router = APIRouter(prefix="/salud-avanzada", tags=["salud-avanzada"])

_NIVEL_MEDICO = 3


# ── Schemas ───────────────────────────────────────────────────────────────────

class MedicamentoIn(BaseModel):
    nombre_medicamento: str = Field(min_length=2, max_length=100)
    dosis: str = Field(min_length=1, max_length=100)
    frecuencia: str
    horario: Optional[str] = None
    via_administracion: str = "ORAL"  # ORAL | TOPICA | INHALADA | INYECTABLE
    prescrito_por: Optional[str] = None
    fecha_inicio: Optional[str] = None
    fecha_fin: Optional[str] = None
    observaciones: Optional[str] = None

class ActaIncidenteIn(BaseModel):
    descripcion_detallada: str = Field(min_length=10)
    testigos: Optional[str] = None
    medidas_tomadas: str
    requirio_traslado: bool = False
    hospital_destino: Optional[str] = None
    notificado_familia: bool = True
    firma_responsable: Optional[str] = None

class PsicosocialIn(BaseModel):
    tipo_atencion: str  # SEGUIMIENTO | INICIAL | CIERRE | DERIVACION
    motivo: str = Field(min_length=5)
    observaciones: str = Field(min_length=5)
    estrategias_sugeridas: Optional[str] = None
    requiere_derivacion: bool = False
    derivado_a: Optional[str] = None
    proxima_sesion: Optional[str] = None

class TutoriaIn(BaseModel):
    alumno_id: uuid.UUID
    tipo_tutoria: str  # ACADEMICA | VOCACIONAL | PERSONAL | GRUPO
    tema: str = Field(min_length=3)
    descripcion: str = Field(min_length=5)
    duracion_minutos: int = Field(default=50, ge=10)
    acuerdos: Optional[str] = None
    proxima_sesion: Optional[str] = None
    requiere_seguimiento: bool = False


# ── SB-003: Medicamentos ──────────────────────────────────────────────────────

@router.get("/medicamentos/{alumno_id}")
async def listar_medicamentos(
    alumno_id: uuid.UUID,
    solo_vigentes: bool = True,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["alumno_id = :aid"]
    params: dict = {"aid": str(alumno_id)}
    if solo_vigentes:
        filters.append("is_active = TRUE")
        filters.append("(fecha_fin IS NULL OR fecha_fin >= CURRENT_DATE)")

    r = await db.execute(text(f"""
        SELECT id, nombre_medicamento, dosis, frecuencia, horario,
               via_administracion, prescrito_por, fecha_inicio, fecha_fin,
               observaciones, is_active
        FROM ades_medicamentos_alumno
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_inicio DESC NULLS LAST
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/medicamentos/{alumno_id}", status_code=201)
async def registrar_medicamento(
    alumno_id: uuid.UUID,
    data: MedicamentoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Se requiere nivel Médico/Coordinador o superior")

    r = await db.execute(text("""
        INSERT INTO ades_medicamentos_alumno
          (alumno_id, nombre_medicamento, dosis, frecuencia, horario,
           via_administracion, prescrito_por, fecha_inicio, fecha_fin,
           observaciones, usuario_creacion, usuario_modificacion)
        VALUES (:aid, :nom, :dosis, :freq, :hora,
                :via, :prescrito, :fi, :ff, :obs, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(alumno_id), "nom": data.nombre_medicamento,
        "dosis": data.dosis, "freq": data.frecuencia, "hora": data.horario,
        "via": data.via_administracion, "prescrito": data.prescrito_por,
        "fi": data.fecha_inicio, "ff": data.fecha_fin,
        "obs": data.observaciones, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Medicamento registrado"}


@router.delete("/medicamentos/{medicamento_id}", status_code=200)
async def suspender_medicamento(
    medicamento_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    await db.execute(text("""
        UPDATE ades_medicamentos_alumno SET is_active = FALSE, usuario_modificacion = :uname WHERE id = :id
    """), {"id": str(medicamento_id), "uname": user.id})
    await db.commit()
    return {"message": "Medicamento suspendido"}


# ── SB-005: Acta de Incidente Médico ─────────────────────────────────────────

@router.post("/actas-incidente/{incidente_id}", status_code=201)
async def generar_acta_incidente(
    incidente_id: uuid.UUID,
    data: ActaIncidenteIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    # Verificar que el incidente existe
    inc = await db.execute(text(
        "SELECT id, alumno_id, tipo_incidente FROM ades_incidentes_medicos WHERE id = :id"
    ), {"id": str(incidente_id)})
    incidente = inc.fetchone()
    if not incidente:
        raise HTTPException(status_code=404, detail="Incidente médico no encontrado")

    r = await db.execute(text("""
        INSERT INTO ades_actas_incidente_medico
          (incidente_id, descripcion_detallada, testigos, medidas_tomadas,
           requirio_traslado, hospital_destino, notificado_familia,
           firma_responsable, usuario_creacion, usuario_modificacion)
        VALUES (:iid, :desc, :test, :medidas,
                :traslado, :hospital, :notif,
                :firma, :uname, :uname)
        RETURNING id
    """), {
        "iid": str(incidente_id),
        "desc": data.descripcion_detallada, "test": data.testigos,
        "medidas": data.medidas_tomadas, "traslado": data.requirio_traslado,
        "hospital": data.hospital_destino, "notif": data.notificado_familia,
        "firma": data.firma_responsable, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Acta de incidente médico generada"}


# ── SB-021: Seguimiento Psicosocial ──────────────────────────────────────────

@router.get("/psicosocial/{alumno_id}")
async def historial_psicosocial(
    alumno_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        SELECT id, tipo_atencion, motivo, observaciones, estrategias_sugeridas,
               requiere_derivacion, derivado_a, proxima_sesion,
               fecha_creacion, usuario_creacion as especialista
        FROM ades_seguimiento_psicosocial
        WHERE alumno_id = :aid
        ORDER BY fecha_creacion DESC
    """), {"aid": str(alumno_id)})
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/psicosocial/{alumno_id}", status_code=201)
async def registrar_sesion_psicosocial(
    alumno_id: uuid.UUID,
    data: PsicosocialIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        INSERT INTO ades_seguimiento_psicosocial
          (alumno_id, tipo_atencion, motivo, observaciones, estrategias_sugeridas,
           requiere_derivacion, derivado_a, proxima_sesion,
           usuario_creacion, usuario_modificacion)
        VALUES (:aid, :tipo, :motivo, :obs, :est,
                :deriv, :deriv_a, :proxima, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(alumno_id), "tipo": data.tipo_atencion,
        "motivo": data.motivo, "obs": data.observaciones,
        "est": data.estrategias_sugeridas, "deriv": data.requiere_derivacion,
        "deriv_a": data.derivado_a, "proxima": data.proxima_sesion,
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Sesión psicosocial registrada"}


# ── SB-022: Tutoría ──────────────────────────────────────────────────────────

@router.get("/tutorias")
async def listar_tutorias(
    alumno_id: Optional[uuid.UUID] = None,
    tipo_tutoria: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["1=1"]
    params: dict = {"skip": skip, "limit": limit}
    if alumno_id:
        filters.append("t.alumno_id = :aid"); params["aid"] = str(alumno_id)
    if tipo_tutoria:
        filters.append("t.tipo_tutoria = :tipo"); params["tipo"] = tipo_tutoria

    r = await db.execute(text(f"""
        SELECT t.id, t.tipo_tutoria, t.tema, t.descripcion,
               t.duracion_minutos, t.acuerdos, t.proxima_sesion, t.requiere_seguimiento,
               t.fecha_creacion, t.usuario_creacion as tutor,
               p.nombre || ' ' || p.apellido_paterno as alumno,
               e.numero_control
        FROM ades_tutorias t
        JOIN ades_estudiantes e ON e.id = t.alumno_id
        JOIN ades_personas p ON p.id = e.persona_id
        WHERE {" AND ".join(filters)}
        ORDER BY t.fecha_creacion DESC
        LIMIT :limit OFFSET :skip
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/tutorias", status_code=201)
async def registrar_tutoria(
    data: TutoriaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_MEDICO:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    r = await db.execute(text("""
        INSERT INTO ades_tutorias
          (alumno_id, tipo_tutoria, tema, descripcion, duracion_minutos,
           acuerdos, proxima_sesion, requiere_seguimiento,
           usuario_creacion, usuario_modificacion)
        VALUES (:aid, :tipo, :tema, :desc, :dur,
                :acuerdos, :proxima, :seguim, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(data.alumno_id), "tipo": data.tipo_tutoria,
        "tema": data.tema, "desc": data.descripcion,
        "dur": data.duracion_minutos, "acuerdos": data.acuerdos,
        "proxima": data.proxima_sesion, "seguim": data.requiere_seguimiento,
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Sesión de tutoría registrada"}


# ── PDF Generators ────────────────────────────────────────────────────────────

@router.get("/incidentes/{incidente_id}/acta-pdf")
async def descargar_acta_incidente(
    incidente_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _user: AdesUser = Depends(get_ades_user),
):
    """Genera el PDF del Acta de Incidente Médico usando WeasyPrint (SB-005)."""
    # 1. Obtener incidente y acta
    r = await db.execute(text("""
        SELECT im.fecha_incidente, im.descripcion, im.tipo_incidente, im.estudiante_id,
               act.descripcion_detallada, act.testigos, act.medidas_tomadas,
               act.requirio_traslado, act.hospital_destino, act.notificado_familia,
               act.fecha_creacion AS fecha_acta, act.id AS acta_id,
               p.nombre || ' ' || p.apellido_paterno || COALESCE(' ' || p.apellido_materno, '') AS nombre_alumno,
               est.matricula, g.nombre_grupo, pl.nombre_plantel
        FROM ades_incidentes_medicos im
        JOIN ades_actas_incidente_medico act ON act.incidente_id = im.id
        JOIN ades_estudiantes est ON est.id = im.estudiante_id
        JOIN ades_personas p ON p.id = est.persona_id
        JOIN ades_inscripciones inscr ON inscr.estudiante_id = est.id AND inscr.is_active = TRUE
        JOIN ades_grupos g ON g.id = inscr.grupo_id
        JOIN ades_planteles pl ON pl.id = est.plantel_id
        WHERE im.id = CAST(:iid AS uuid)
        LIMIT 1
    """), {"iid": str(incidente_id)})
    row = r.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Acta de incidente médico no encontrada")

    # 2. Obtener especialista responsable
    esp_r = await db.execute(text("""
        SELECT p.nombre || ' ' || p.apellido_paterno AS nombre_medico
        FROM ades_personal_salud ps
        JOIN ades_personas p ON p.id = ps.persona_id
        WHERE ps.plantel_id = (SELECT plantel_id FROM ades_estudiantes WHERE id = :aid)
        LIMIT 1
    """), {"aid": row["estudiante_id"]})
    esp_row = esp_r.fetchone()
    especialista = esp_row[0] if esp_row else "Médico Escolar"

    # 3. Renderizar Jinja2
    ctx = {
        "fecha_registro": row["fecha_acta"].strftime("%d/%m/%Y"),
        "folio_acta": str(row["acta_id"])[:8].upper(),
        "nombre_alumno": row["nombre_alumno"],
        "matricula": row["matricula"],
        "grupo": row["nombre_grupo"],
        "tipo_incidente": row["tipo_incidente"],
        "fecha_incidente": row["fecha_incidente"].strftime("%d/%m/%Y %H:%M"),
        "descripcion_detallada": row["descripcion_detallada"],
        "tratamiento_aplicado": row["medidas_tomadas"],
        "requirio_traslado": row["requirio_traslado"],
        "hospital_destino": row["hospital_destino"],
        "notificado_familia": row["notificado_familia"],
        "testigos": row["testigos"],
        "especialista": especialista
    }

    template = _get_jinja().get_template("acta_incidente.html")
    html_str = template.render(**ctx)

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html_str, base_url=str(TEMPLATES_DIR)).write_pdf()
    except ImportError:
        raise HTTPException(status_code=503, detail="WeasyPrint no disponible en este entorno.")

    filename = f"acta_incidente_{row['matricula']}.pdf"
    return StreamingResponse(
        BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/certificado-deportivo/{alumno_id}")
async def descargar_certificado_deportivo(
    alumno_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _user: AdesUser = Depends(get_ades_user),
):
    """Genera el Certificado Médico de Aptitud Física para Deportes (SB-009) usando WeasyPrint."""
    # 1. Obtener datos del alumno
    r = await db.execute(text("""
        SELECT est.id, est.matricula,
               p.nombre || ' ' || p.apellido_paterno || COALESCE(' ' || p.apellido_materno, '') AS nombre_alumno,
               g.nombre_grupo,
               em.tipo_sangre, em.alergias, em.condiciones_cronicas
        FROM ades_estudiantes est
        JOIN ades_personas p ON p.id = est.persona_id
        LEFT JOIN ades_inscripciones inscr ON inscr.estudiante_id = est.id AND inscr.is_active = TRUE
        LEFT JOIN ades_grupos g ON g.id = inscr.grupo_id
        LEFT JOIN ades_expedientes_medicos em ON em.estudiante_id = est.id
        WHERE est.id = CAST(:aid AS uuid)
        LIMIT 1
    """), {"aid": str(alumno_id)})
    row = r.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Estudiante no encontrado")

    # 2. Obtener especialista responsable
    esp_r = await db.execute(text("""
        SELECT p.nombre || ' ' || p.apellido_paterno AS nombre_medico, ps.cedula_profesional
        FROM ades_personal_salud ps
        JOIN ades_personas p ON p.id = ps.persona_id
        WHERE ps.plantel_id = (SELECT plantel_id FROM ades_estudiantes WHERE id = :aid)
        LIMIT 1
    """), {"aid": str(alumno_id)})
    esp_row = esp_r.mappings().first()
    especialista = esp_row["nombre_medico"] if esp_row else "Médico Escolar"
    cedula = esp_row["cedula_profesional"] if esp_row else "En trámite"

    # 3. Renderizar Jinja2
    ctx = {
        "fecha_emision": datetime.now().strftime("%d/%m/%Y"),
        "nombre_alumno": row["nombre_alumno"],
        "matricula": row["matricula"],
        "grupo": row["nombre_grupo"] or "Sin grupo",
        "tipo_sangre": row["tipo_sangre"],
        "alergias": row["alergias"],
        "condiciones_cronicas": row["condiciones_cronicas"],
        "especialista": especialista,
        "cedula": cedula
    }

    template = _get_jinja().get_template("certificado_deportivo.html")
    html_str = template.render(**ctx)

    try:
        from weasyprint import HTML
        pdf_bytes = HTML(string=html_str, base_url=str(TEMPLATES_DIR)).write_pdf()
    except ImportError:
        raise HTTPException(status_code=503, detail="WeasyPrint no disponible en este entorno.")

    filename = f"certificado_deportivo_{row['matricula']}.pdf"
    return StreamingResponse(
        BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

