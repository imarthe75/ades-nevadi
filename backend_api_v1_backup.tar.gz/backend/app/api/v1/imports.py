"""
Importación masiva desde CSV/Excel.

Endpoints:
  GET  /imports/plantillas/{entidad}   — descarga CSV de ejemplo
  POST /imports/alumnos
  POST /imports/profesores
  POST /imports/materias
  POST /imports/grupos

Columnas esperadas (tolerante a variantes con/sin acentos, espacios→guión_bajo):

  alumnos:
    nombre | apellido_paterno | apellido_materno | curp | genero | fecha_nacimiento |
    fecha_ingreso | clave_plantel

  profesores:
    nombre | apellido_paterno | apellido_materno | curp | genero | fecha_nacimiento |
    numero_empleado | tipo_contrato | clave_plantel

  materias:
    nombre_materia | clave_materia | nombre_nivel | horas_semana

  grupos:
    nombre_grupo | turno | capacidad_maxima | nombre_grado | nombre_ciclo
"""
from __future__ import annotations
import csv
import io
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user, get_ades_user, AdesUser
from app.models.personas import Persona, Estudiante, Profesor, Estatus
from app.models.academica import (
    Plantel, NivelEducativo, Grado, CicloEscolar, Grupo,
)
from app.models.fase3 import Aula
from app.models.materias import Materia
from app.utils.importador import parse_file, get_col, parse_date, parse_float, parse_int

router = APIRouter(prefix="/imports", tags=["importación"])


# ── Modelos de respuesta ───────────────────────────────────────────────────────

class ErrorFila(BaseModel):
    fila: int
    dato: str
    error: str


class ImportResult(BaseModel):
    entidad: str
    total: int
    exitosos: int
    errores: int
    detalle_errores: list[ErrorFila]


# ── Plantillas CSV ─────────────────────────────────────────────────────────────

_PLANTILLAS: dict[str, tuple[list[str], list[list[str]]]] = {
    "alumnos": (
        ["nombre", "apellido_paterno", "apellido_materno", "curp",
         "genero", "fecha_nacimiento", "fecha_ingreso", "clave_plantel"],
        [["Juan", "García", "López", "GALJ900101HMCRPN01",
          "M", "01/01/1990", "15/08/2024", "NV-PRI-001"]],
    ),
    "profesores": (
        ["nombre", "apellido_paterno", "apellido_materno", "curp",
         "genero", "fecha_nacimiento", "numero_empleado", "tipo_contrato", "clave_plantel"],
        [["María", "Pérez", "Sánchez", "PESM850315MMCRNR02",
          "F", "15/03/1985", "EMP-001", "BASE", "NV-PRI-001"]],
    ),
    "materias": (
        ["nombre_materia", "clave_materia", "nombre_nivel", "horas_semana"],
        [["Matemáticas", "MAT-01", "Primaria", "5"],
         ["Español",     "ESP-01", "Primaria", "5"]],
    ),
    "grupos": (
        ["nombre_grupo", "turno", "capacidad_maxima", "nombre_grado", "nombre_ciclo"],
        [["1A", "MATUTINO", "35", "Primer Grado", "2024-2025"],
         ["2B", "VESPERTINO", "30", "Segundo Grado", "2024-2025"]],
    ),
    "aulas": (
        ["nombre_aula", "tipo_aula", "capacidad_alumnos", "clave_plantel", "tiene_proyector", "tiene_pizarra_digital", "tiene_internet", "observaciones"],
        [["Aula 101", "SALON", "35", "NV-PRI-001", "SI", "NO", "SI", "Planta baja"],
         ["Lab Cómputo", "COMPUTO", "25", "NV-PRI-001", "SI", "SI", "SI", "Planta alta"]],
    ),
    "preinscritos_sep": (
        ["nombre", "apellido_paterno", "apellido_materno", "curp", "fecha_nacimiento",
         "nivel_solicitado", "grado_solicitado", "clave_plantel", "nombre_ciclo",
         "nombre_tutor", "telefono_tutor", "email_tutor", "escuela_procedencia", "promedio_procedencia"],
        [["Ana Sofia", "Díaz", "Morales", "DIMA150228HMCRRL03", "28/02/2015",
          "Primaria", "3", "NV-PRI-001", "2026-2027",
          "Carlos Díaz", "7221234567", "carlos@gmail.com", "Colegio México", "9.20"]],
    ),
}


@router.get("/plantillas/{entidad}")
async def descargar_plantilla(
    entidad: str,
    _user: dict = Depends(get_current_user),
):
    if entidad not in _PLANTILLAS:
        raise HTTPException(
            status_code=404,
            detail=f"Plantilla no disponible. Opciones: {', '.join(_PLANTILLAS)}",
        )
    headers, ejemplos = _PLANTILLAS[entidad]
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(headers)
    for fila in ejemplos:
        writer.writerow(fila)
    content = buf.getvalue().encode("utf-8-sig")
    return StreamingResponse(
        iter([content]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=plantilla_{entidad}.csv"},
    )


# ── Helpers internos ───────────────────────────────────────────────────────────

async def _resolver_plantel(
    clave: str,
    planteles_por_clave: dict[str, uuid.UUID],
    planteles_por_nombre: dict[str, uuid.UUID],
) -> uuid.UUID | None:
    """Resuelve plantel por clave_ct, nombre o UUID directo."""
    if not clave:
        return None
    pid = planteles_por_clave.get(clave) or planteles_por_nombre.get(clave.lower())
    if pid:
        return pid
    try:
        return uuid.UUID(clave)
    except (ValueError, AttributeError):
        return None


# ── POST /imports/alumnos ──────────────────────────────────────────────────────

_MAX_FILE_BYTES = 10 * 1024 * 1024  # 10 MB
_ALLOWED_MIME = {"text/csv", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}


def _validar_archivo(file: UploadFile, content: bytes) -> None:
    if len(content) > _MAX_FILE_BYTES:
        raise HTTPException(status_code=413, detail="El archivo supera el límite de 10 MB")
    mime = (file.content_type or "").split(";")[0].strip()
    ext = (file.filename or "").rsplit(".", 1)[-1].lower()
    if mime and mime not in _ALLOWED_MIME and ext not in ("csv", "xlsx"):
        raise HTTPException(status_code=400, detail=f"Tipo de archivo no permitido: {mime}")


@router.post("/alumnos", response_model=ImportResult)
async def importar_alumnos(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores y coordinadores pueden importar alumnos")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    # Cachés
    p_res = await db.execute(select(Plantel))
    planteles_clave  = {p.clave_ct: p.id for p in p_res.scalars().all() if p.clave_ct}
    p_res2 = await db.execute(select(Plantel))
    planteles_nombre = {p.nombre_plantel.lower(): p.id for p in p_res2.scalars().all()}

    est_res = await db.execute(
        select(Estatus).where(Estatus.entidad == "ESTUDIANTE", Estatus.nombre_estatus == "INSCRITO")
    )
    estatus_obj = est_res.scalar_one_or_none()
    estatus_id  = estatus_obj.id if estatus_obj else None

    cnt = await db.execute(select(func.count()).select_from(Estudiante))
    seq = cnt.scalar() or 0

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        curp   = get_col(row, headers, "curp").upper()
        nombre = get_col(row, headers, "nombre")
        if not curp or not nombre:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}", error="'nombre' y 'curp' son obligatorios"))
            continue

        dup = await db.execute(select(Persona.id).where(Persona.curp == curp))
        if dup.scalar_one_or_none():
            errores.append(ErrorFila(fila=i, dato=curp, error="CURP ya registrada"))
            continue

        clave_plantel = get_col(row, headers, "clave_plantel", "plantel", "clave_ct")
        plantel_id = await _resolver_plantel(clave_plantel, planteles_clave, planteles_nombre)
        if not plantel_id:
            errores.append(ErrorFila(fila=i, dato=curp, error=f"Plantel no encontrado: '{clave_plantel}'"))
            continue

        sp = await db.begin_nested()
        try:
            persona = Persona(
                nombre=nombre,
                apellido_paterno=get_col(row, headers, "apellido_paterno"),
                apellido_materno=get_col(row, headers, "apellido_materno") or None,
                curp=curp,
                genero=get_col(row, headers, "genero") or None,
                fecha_nacimiento=parse_date(get_col(row, headers, "fecha_nacimiento")),
            )
            db.add(persona)
            await db.flush()

            seq += 1
            estudiante = Estudiante(
                matricula=f"MAT-{seq:06d}",
                persona_id=persona.id,
                plantel_id=plantel_id,
                fecha_ingreso=parse_date(get_col(row, headers, "fecha_ingreso")),
                estatus_id=estatus_id,
            )
            db.add(estudiante)
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=curp, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="alumnos", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)


# ── POST /imports/profesores ───────────────────────────────────────────────────

@router.post("/profesores", response_model=ImportResult)
async def importar_profesores(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores y coordinadores pueden importar profesores")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    p_res = await db.execute(select(Plantel))
    planteles_clave  = {p.clave_ct: p.id for p in p_res.scalars().all() if p.clave_ct}
    p_res2 = await db.execute(select(Plantel))
    planteles_nombre = {p.nombre_plantel.lower(): p.id for p in p_res2.scalars().all()}

    est_res = await db.execute(
        select(Estatus).where(Estatus.entidad == "PROFESOR", Estatus.nombre_estatus == "ACTIVO")
    )
    estatus_obj = est_res.scalar_one_or_none()
    estatus_id  = estatus_obj.id if estatus_obj else None

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        curp   = get_col(row, headers, "curp").upper()
        nombre = get_col(row, headers, "nombre")
        num_emp = get_col(row, headers, "numero_empleado", "num_empleado", "empleado")
        if not curp or not nombre or not num_emp:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}",
                                     error="'nombre', 'curp' y 'numero_empleado' son obligatorios"))
            continue

        dup = await db.execute(select(Persona.id).where(Persona.curp == curp))
        if dup.scalar_one_or_none():
            errores.append(ErrorFila(fila=i, dato=curp, error="CURP ya registrada"))
            continue

        clave_plantel = get_col(row, headers, "clave_plantel", "plantel", "clave_ct")
        plantel_id = await _resolver_plantel(clave_plantel, planteles_clave, planteles_nombre)
        if not plantel_id:
            errores.append(ErrorFila(fila=i, dato=curp, error=f"Plantel no encontrado: '{clave_plantel}'"))
            continue

        tipo_contrato = get_col(row, headers, "tipo_contrato", "contrato") or "BASE"

        sp = await db.begin_nested()
        try:
            persona = Persona(
                nombre=nombre,
                apellido_paterno=get_col(row, headers, "apellido_paterno"),
                apellido_materno=get_col(row, headers, "apellido_materno") or None,
                curp=curp,
                genero=get_col(row, headers, "genero") or None,
                fecha_nacimiento=parse_date(get_col(row, headers, "fecha_nacimiento")),
            )
            db.add(persona)
            await db.flush()

            profesor = Profesor(
                persona_id=persona.id,
                plantel_id=plantel_id,
                numero_empleado=num_emp,
                tipo_contrato=tipo_contrato.upper(),
                estatus_id=estatus_id,
            )
            db.add(profesor)
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=curp, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="profesores", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)


# ── POST /imports/materias ─────────────────────────────────────────────────────

@router.post("/materias", response_model=ImportResult)
async def importar_materias(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores y coordinadores pueden importar materias")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    niv_res = await db.execute(select(NivelEducativo))
    niveles = {n.nombre_nivel.lower(): n.id for n in niv_res.scalars().all()}

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        nombre_mat = get_col(row, headers, "nombre_materia", "materia", "nombre")
        if not nombre_mat:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}", error="'nombre_materia' es obligatorio"))
            continue

        nombre_nivel = get_col(row, headers, "nombre_nivel", "nivel")
        nivel_id = niveles.get(nombre_nivel.lower())
        if not nivel_id:
            try:
                nivel_id = uuid.UUID(nombre_nivel)
            except (ValueError, AttributeError):
                errores.append(ErrorFila(fila=i, dato=nombre_mat,
                                         error=f"Nivel educativo no encontrado: '{nombre_nivel}'"))
                continue

        sp = await db.begin_nested()
        try:
            materia = Materia(
                nombre_materia=nombre_mat,
                clave_materia=get_col(row, headers, "clave_materia", "clave") or None,
                nivel_educativo_id=nivel_id,
                horas_semana=parse_float(get_col(row, headers, "horas_semana", "horas")),
            )
            db.add(materia)
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=nombre_mat, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="materias", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)


# ── POST /imports/grupos ───────────────────────────────────────────────────────

@router.post("/grupos", response_model=ImportResult)
async def importar_grupos(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores y coordinadores pueden importar grupos")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    grado_res = await db.execute(select(Grado))
    grados_nombre = {g.nombre_grado.lower(): g.id for g in grado_res.scalars().all()}

    ciclo_res = await db.execute(select(CicloEscolar))
    ciclos_nombre = {c.nombre_ciclo.lower(): c.id for c in ciclo_res.scalars().all()}

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        nombre_grupo = get_col(row, headers, "nombre_grupo", "grupo")
        if not nombre_grupo:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}", error="'nombre_grupo' es obligatorio"))
            continue

        nombre_grado = get_col(row, headers, "nombre_grado", "grado")
        grado_id = grados_nombre.get(nombre_grado.lower())
        if not grado_id:
            try:
                grado_id = uuid.UUID(nombre_grado)
            except (ValueError, AttributeError):
                errores.append(ErrorFila(fila=i, dato=nombre_grupo,
                                         error=f"Grado no encontrado: '{nombre_grado}'"))
                continue

        nombre_ciclo = get_col(row, headers, "nombre_ciclo", "ciclo", "ciclo_escolar")
        ciclo_id = ciclos_nombre.get(nombre_ciclo.lower())
        if not ciclo_id:
            try:
                ciclo_id = uuid.UUID(nombre_ciclo)
            except (ValueError, AttributeError):
                errores.append(ErrorFila(fila=i, dato=nombre_grupo,
                                         error=f"Ciclo escolar no encontrado: '{nombre_ciclo}'"))
                continue

        turno = (get_col(row, headers, "turno") or "MATUTINO").upper()
        capacidad = parse_int(get_col(row, headers, "capacidad_maxima", "capacidad")) or 35

        sp = await db.begin_nested()
        try:
            grupo = Grupo(
                nombre_grupo=nombre_grupo,
                grado_id=grado_id,
                ciclo_escolar_id=ciclo_id,
                turno=turno,
                capacidad_maxima=capacidad,
            )
            db.add(grupo)
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=nombre_grupo, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="grupos", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)


# ── POST /imports/aulas ────────────────────────────────────────────────────────

@router.post("/aulas", response_model=ImportResult)
async def importar_aulas(
    file: UploadFile = File(...),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > 3:
        raise HTTPException(status_code=403, detail="Solo coordinadores o superiores pueden importar aulas")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    plantel_res = await db.execute(select(Plantel))
    planteles_clave = {p.clave_ct.lower(): p.id for p in plantel_res.scalars().all() if p.clave_ct}

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        nombre_aula = get_col(row, headers, "nombre_aula", "nombre", "aula")
        if not nombre_aula:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}", error="'nombre_aula' es obligatorio"))
            continue

        clave_plantel = get_col(row, headers, "clave_plantel", "plantel")
        plantel_id = planteles_clave.get((clave_plantel or "").lower())

        tipo_aula = (get_col(row, headers, "tipo_aula", "tipo") or "SALON").upper()
        capacidad = parse_int(get_col(row, headers, "capacidad", "capacidad_maxima")) or 30

        def _bool_col(name: str) -> bool:
            v = (get_col(row, headers, name) or "").strip().upper()
            return v in ("SI", "SÍ", "YES", "TRUE", "1", "S")

        tiene_proyector = _bool_col("tiene_proyector")
        tiene_pizarra_digital = _bool_col("tiene_pizarra_digital")
        tiene_internet = _bool_col("tiene_internet")
        observaciones = get_col(row, headers, "observaciones", "ubicacion", "ubicacion_fisica") or None

        sp = await db.begin_nested()
        try:
            aula = Aula(
                nombre_aula=nombre_aula,
                tipo_aula=tipo_aula,
                capacidad_alumnos=capacidad,
                plantel_id=plantel_id,
                tiene_proyector=tiene_proyector,
                tiene_pizarra_digital=tiene_pizarra_digital,
                tiene_internet=tiene_internet,
                observaciones=observaciones,
                usuario_creacion=user.id,
                usuario_modificacion=user.id,
            )
            db.add(aula)
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=nombre_aula, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="aulas", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)


# ── POST /imports/preinscritos-sep ─────────────────────────────────────────────

@router.post("/preinscritos-sep", response_model=ImportResult)
async def importar_preinscritos_sep(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    ades_user: AdesUser = Depends(get_ades_user),
):
    if ades_user.nivel_acceso > 2:
        raise HTTPException(status_code=403, detail="Solo administradores y coordinadores pueden importar preinscritos de la SEP")

    content = await file.read()
    _validar_archivo(file, content)
    headers, rows = parse_file(content, file.filename or "upload.csv")
    if not rows:
        raise HTTPException(status_code=400, detail="El archivo no contiene datos")

    # Cachés de Planteles y Ciclos
    p_res = await db.execute(select(Plantel))
    planteles_clave = {p.clave_ct: p.id for p in p_res.scalars().all() if p.clave_ct}
    p_res2 = await db.execute(select(Plantel))
    planteles_nombre = {p.nombre_plantel.lower(): p.id for p in p_res2.scalars().all()}

    ciclo_res = await db.execute(select(CicloEscolar))
    ciclos_nombre = {c.nombre_ciclo.lower(): c.id for c in ciclo_res.scalars().all()}

    errores: list[ErrorFila] = []
    exitosos = 0

    for i, row in enumerate(rows, start=2):
        curp = get_col(row, headers, "curp").upper()
        nombre = get_col(row, headers, "nombre")
        apellido_p = get_col(row, headers, "apellido_paterno", "apellido_p")
        apellido_m = get_col(row, headers, "apellido_materno", "apellido_m") or None
        fecha_nac = get_col(row, headers, "fecha_nacimiento", "fecha_nac")
        nivel = get_col(row, headers, "nivel_solicitado", "nivel")
        grado_str = get_col(row, headers, "grado_solicitado", "grado")
        clave_plantel = get_col(row, headers, "clave_plantel", "plantel", "clave_ct")
        nombre_ciclo = get_col(row, headers, "nombre_ciclo", "ciclo", "ciclo_escolar")
        tutor = get_col(row, headers, "nombre_tutor", "tutor") or "Tutor Pendiente"

        if not curp or not nombre or not apellido_p or not fecha_nac or not nivel or not grado_str or not nombre_ciclo:
            errores.append(ErrorFila(fila=i, dato=f"fila {i}", error="Campos obligatorios faltantes (nombre, apellido_p, curp, fecha_nac, nivel, grado, ciclo)"))
            continue

        # Validaciones de duplicados en admisiones
        dup_adm = await db.execute(
            text("SELECT id FROM public.ades_solicitudes_admision WHERE curp = :curp AND estado NOT IN ('RECHAZADO')"),
            {"curp": curp}
        )
        if dup_adm.fetchone():
            errores.append(ErrorFila(fila=i, dato=curp, error="Ya existe una solicitud de admisión activa para esta CURP"))
            continue

        # Validaciones de duplicados en estudiantes/usuarios
        dup_est = await db.execute(
            text("SELECT id FROM public.ades_personas WHERE curp = :curp"),
            {"curp": curp}
        )
        if dup_est.fetchone():
            errores.append(ErrorFila(fila=i, dato=curp, error="CURP ya registrada en el sistema escolar (alumno o usuario activo)"))
            continue

        # Resolver plantel
        plantel_id = await _resolver_plantel(clave_plantel, planteles_clave, planteles_nombre)
        if not plantel_id:
            errores.append(ErrorFila(fila=i, dato=curp, error=f"Plantel no encontrado: '{clave_plantel}'"))
            continue

        # Resolver ciclo
        ciclo_id = ciclos_nombre.get(nombre_ciclo.lower())
        if not ciclo_id:
            try:
                ciclo_id = uuid.UUID(nombre_ciclo)
            except (ValueError, AttributeError):
                errores.append(ErrorFila(fila=i, dato=curp, error=f"Ciclo escolar no encontrado: '{nombre_ciclo}'"))
                continue

        grado = parse_int(grado_str)
        if grado is None:
            errores.append(ErrorFila(fila=i, dato=curp, error=f"Grado no válido: '{grado_str}'"))
            continue

        sp = await db.begin_nested()
        try:
            parsed_date = parse_date(fecha_nac)
            await db.execute(
                text("""
                    INSERT INTO public.ades_solicitudes_admision
                        (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, curp,
                         nivel_solicitado, grado_solicitado, plantel_id, ciclo_escolar_id,
                         nombre_tutor, telefono_tutor, email_tutor, escuela_procedencia, promedio_procedencia,
                         estado, usuario_creacion, usuario_modificacion)
                    VALUES
                        (:nombre, :ap_pat, :ap_mat, :fecha_nac, :curp,
                         :nivel, :grado, :plantel_id, :ciclo_id,
                         :tutor, :tel_tutor, :email_tutor, :escuela, :promedio,
                         'PENDIENTE', :user_id, :user_id)
                """),
                {
                    "nombre": nombre, "ap_pat": apellido_p, "ap_mat": apellido_m, "fecha_nac": parsed_date, "curp": curp,
                    "nivel": nivel, "grado": grado, "plantel_id": plantel_id, "ciclo_id": ciclo_id,
                    "tutor": tutor,
                    "tel_tutor": get_col(row, headers, "telefono_tutor", "tel_tutor") or None,
                    "email_tutor": get_col(row, headers, "email_tutor", "correo_tutor") or None,
                    "escuela": get_col(row, headers, "escuela_procedencia", "procedencia") or None,
                    "promedio": parse_float(get_col(row, headers, "promedio_procedencia", "promedio")),
                    "user_id": str(ades_user.id)
                }
            )
            await db.flush()
            exitosos += 1
        except Exception as exc:
            await sp.rollback()
            errores.append(ErrorFila(fila=i, dato=curp, error=str(exc)[:150]))
            continue

    await db.commit()
    return ImportResult(entidad="preinscritos_sep", total=len(rows),
                        exitosos=exitosos, errores=len(errores),
                        detalle_errores=errores)
