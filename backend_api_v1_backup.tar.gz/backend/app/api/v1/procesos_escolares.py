"""
FASE 39 — Procesos Escolares Completos

  PE-003  GET/POST  /procesos/admision                   — solicitudes de admisión nuevos alumnos
  PE-005  POST      /procesos/admision/{id}/aceptar      — aceptar/rechazar solicitud
  PE-006  GET/POST  /procesos/documentos-admision        — checklist de documentos requeridos
  PE-007  POST      /procesos/preinscripcion             — preinscripción en línea
  PE-011  GET       /procesos/lista-espera               — lista de espera por nivel/plantel
  PE-012  POST      /procesos/lista-espera/{id}/notificar— notificar lugar disponible
  PE-014  GET/POST  /procesos/optativas                  — inscripción a materias optativas
  PE-026  POST      /procesos/acuerdo-convivencia        — firma digital acuerdo de convivencia
  AC-005  GET/POST  /procesos/calendarios-academicos     — calendarios académicos SEP/UAEMEX
  AC-014  POST      /procesos/periodos-evaluacion        — apertura/cierre periodos evaluación
  AC-015  GET       /procesos/calendario-actividades     — actividades del ciclo escolar
"""
from __future__ import annotations
import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import get_ades_user, AdesUser
from app.api.v1.carbone import _carbone_render

router = APIRouter(prefix="/procesos", tags=["procesos-escolares"])

_NIVEL_ADMIN = 2
_NIVEL_SECRETARIA = 3


# ── Schemas ───────────────────────────────────────────────────────────────────

class AdmisionIn(BaseModel):
    nombre: str = Field(min_length=2, max_length=100)
    apellido_paterno: str = Field(min_length=2, max_length=80)
    apellido_materno: Optional[str] = None
    fecha_nacimiento: str
    curp: str = Field(min_length=18, max_length=18)
    nivel_solicitado: str  # PRIMARIA | SECUNDARIA | PREPARATORIA
    grado_solicitado: int = Field(ge=1, le=6)
    plantel_id: uuid.UUID
    nombre_tutor: str
    telefono_tutor: str
    email_tutor: Optional[str] = None
    escuela_procedencia: Optional[str] = None
    promedio_procedencia: Optional[float] = None

class AdmisionResolucionIn(BaseModel):
    decision: str  # ACEPTADO | LISTA_ESPERA | RECHAZADO
    motivo: Optional[str] = None
    grupo_asignado_id: Optional[uuid.UUID] = None

class PreinscripcionIn(BaseModel):
    admision_id: uuid.UUID
    ciclo_escolar_id: uuid.UUID
    grupo_id: uuid.UUID

class OptativaIn(BaseModel):
    estudiante_id: uuid.UUID
    materia_id: uuid.UUID
    ciclo_escolar_id: uuid.UUID

class AcuerdoIn(BaseModel):
    alumno_id: uuid.UUID
    tutor_nombre: str
    tutor_firma_hash: Optional[str] = None
    ip_firma: Optional[str] = None

class CalendarioAcademicoIn(BaseModel):
    nombre: str = Field(min_length=3, max_length=150)
    ciclo_escolar_id: uuid.UUID
    nivel_educativo: str
    tipo: str  # DIAS_INHABILES | EXAMENES | EVENTOS | VACACIONES
    fecha_inicio: str
    fecha_fin: str
    descripcion: Optional[str] = None
    es_oficial: bool = True

class PeriodoEvaluacionIn(BaseModel):
    ciclo_escolar_id: uuid.UUID
    nombre_periodo: str
    nivel_educativo: str
    fecha_inicio: str
    fecha_fin: str
    tipo_evaluacion: str  # PARCIAL | FINAL | EXTRAORDINARIO | DIAGNOSTICO
    abierto: bool = True

class EvaluacionDiagnosticoIn(BaseModel):
    puntuacion_diagnostico: float = Field(ge=0, le=100)
    observaciones_diagnostico: Optional[str] = None

class BajaIn(BaseModel):
    estudiante_id: uuid.UUID
    inscripcion_id: Optional[uuid.UUID] = None
    tipo_baja: str  # TEMPORAL | DEFINITIVA | TRASLADO | DESERCION
    motivo: Optional[str] = None
    fecha_efectiva: str
    observaciones: Optional[str] = None


# ── PE-003: Solicitudes de admisión ──────────────────────────────────────────

@router.get("/admision")
async def listar_admisiones(
    plantel_id: Optional[uuid.UUID] = None,
    estado: Optional[str] = None,
    ciclo_id: Optional[uuid.UUID] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, le=200),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["1=1"]
    params: dict = {"skip": skip, "limit": limit}
    if plantel_id:
        filters.append("plantel_id = :plid"); params["plid"] = str(plantel_id)
    if estado:
        filters.append("estado = :estado"); params["estado"] = estado
    if ciclo_id:
        filters.append("ciclo_escolar_id = :cid"); params["cid"] = str(ciclo_id)

    r = await db.execute(text(f"""
        SELECT id, nombre, apellido_paterno, apellido_materno, curp,
               nivel_solicitado, grado_solicitado, estado,
               nombre_tutor, email_tutor, fecha_solicitud,
               promedio_procedencia, escuela_procedencia
        FROM ades_solicitudes_admision
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_solicitud DESC
        LIMIT :limit OFFSET :skip
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/admision", status_code=201)
async def crear_solicitud_admision(
    data: AdmisionIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    # Verificar CURP no duplicada en solicitudes activas
    dup = await db.execute(text(
        "SELECT id FROM ades_solicitudes_admision WHERE curp = :curp AND estado NOT IN ('RECHAZADO')"
    ), {"curp": data.curp})
    if dup.fetchone():
        raise HTTPException(status_code=409, detail="Ya existe una solicitud activa con este CURP")

    r = await db.execute(text("""
        INSERT INTO ades_solicitudes_admision
          (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, curp,
           nivel_solicitado, grado_solicitado, plantel_id,
           nombre_tutor, telefono_tutor, email_tutor,
           escuela_procedencia, promedio_procedencia,
           estado, usuario_creacion, usuario_modificacion)
        VALUES (:nom, :ap, :am, :fnac, :curp,
                :nivel, :grado, :plid,
                :tutor, :tel, :email,
                :escuela, :prom,
                'PENDIENTE', :uname, :uname)
        RETURNING id
    """), {
        "nom": data.nombre, "ap": data.apellido_paterno, "am": data.apellido_materno,
        "fnac": data.fecha_nacimiento, "curp": data.curp,
        "nivel": data.nivel_solicitado, "grado": data.grado_solicitado,
        "plid": str(data.plantel_id),
        "tutor": data.nombre_tutor, "tel": data.telefono_tutor, "email": data.email_tutor,
        "escuela": data.escuela_procedencia, "prom": data.promedio_procedencia,
        "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Solicitud de admisión registrada", "estado": "PENDIENTE"}


# ── PE-005: Resolver admisión ─────────────────────────────────────────────────

@router.post("/admision/{admision_id}/aceptar", status_code=200)
async def resolver_admision(
    admision_id: uuid.UUID,
    data: AdmisionResolucionIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin Plantel o superior")

    sol = await db.execute(text(
        "SELECT id, estado FROM ades_solicitudes_admision WHERE id = :id"
    ), {"id": str(admision_id)})
    solicitud = sol.fetchone()
    if not solicitud:
        raise HTTPException(status_code=404, detail="Solicitud no encontrada")
    if solicitud._mapping["estado"] != "PENDIENTE":
        raise HTTPException(status_code=400, detail=f"La solicitud ya fue resuelta: {solicitud._mapping['estado']}")

    await db.execute(text("""
        UPDATE ades_solicitudes_admision
        SET estado = :decision, motivo_decision = :motivo,
            grupo_asignado_id = :grupo, fecha_resolucion = CURRENT_TIMESTAMP,
            resuelto_por = :autor, usuario_modificacion = :uname
        WHERE id = :id
    """), {
        "decision": data.decision, "motivo": data.motivo,
        "grupo": str(data.grupo_asignado_id) if data.grupo_asignado_id else None,
        "autor": str(user.db_id) if user.db_id else None,
        "uname": user.id, "id": str(admision_id),
    })
    await db.commit()
    return {"message": f"Solicitud {data.decision.lower()}", "estado": data.decision}


# ── PE-006: Documentos de admisión ───────────────────────────────────────────

@router.get("/documentos-admision")
async def listar_documentos_admision(
    admision_id: Optional[uuid.UUID] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["1=1"]
    params: dict = {}
    if admision_id:
        filters.append("admision_id = :aid"); params["aid"] = str(admision_id)

    r = await db.execute(text(f"""
        SELECT id, admision_id, tipo_documento, nombre_archivo, url_documento,
               estado_validacion, observaciones, fecha_creacion
        FROM ades_documentos_admision
        WHERE {" AND ".join(filters)}
        ORDER BY tipo_documento
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


# ── PE-007: Preinscripción ────────────────────────────────────────────────────

@router.post("/preinscripcion", status_code=201)
async def preinscribir_alumno(
    data: PreinscripcionIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    # Verificar solicitud aceptada
    sol = await db.execute(text("""
        SELECT id, nombre, apellido_paterno, curp
        FROM ades_solicitudes_admision
        WHERE id = :aid AND estado = 'ACEPTADO'
    """), {"aid": str(data.admision_id)})
    solicitud = sol.fetchone()
    if not solicitud:
        raise HTTPException(status_code=400, detail="La solicitud debe estar en estado ACEPTADO")

    # Verificar capacidad del grupo
    cap = await db.execute(text("""
        SELECT capacidad_maxima,
               (SELECT COUNT(*) FROM ades_inscripciones WHERE grupo_id = :gid AND is_active) as inscritos
        FROM ades_grupos WHERE id = :gid AND is_active
    """), {"gid": str(data.grupo_id)})
    grupo = cap.fetchone()
    if not grupo:
        raise HTTPException(status_code=404, detail="Grupo no encontrado")
    gm = dict(grupo._mapping)
    if gm["inscritos"] >= gm["capacidad_maxima"]:
        raise HTTPException(status_code=400, detail="El grupo está lleno")

    # Crear persona y estudiante a partir de la solicitud
    s = dict(solicitud._mapping)
    persona_r = await db.execute(text("""
        INSERT INTO ades_personas (nombre, apellido_paterno, curp, usuario_creacion, usuario_modificacion)
        VALUES (:nom, :ap, :curp, :uname, :uname)
        RETURNING id
    """), {"nom": s["nombre"], "ap": s["apellido_paterno"], "curp": s["curp"], "uname": user.id})
    persona_id = str(persona_r.fetchone()._mapping["id"])

    est_r = await db.execute(text("""
        INSERT INTO ades_estudiantes (persona_id, usuario_creacion, usuario_modificacion)
        VALUES (:pid, :uname, :uname) RETURNING id
    """), {"pid": persona_id, "uname": user.id})
    estudiante_id = str(est_r.fetchone()._mapping["id"])

    # Inscribir
    await db.execute(text("""
        INSERT INTO ades_inscripciones
          (estudiante_id, grupo_id, ciclo_escolar_id, fecha_inscripcion,
           usuario_creacion, usuario_modificacion)
        VALUES (:eid, :gid, :cid, CURRENT_DATE, :uname, :uname)
    """), {
        "eid": estudiante_id, "gid": str(data.grupo_id),
        "cid": str(data.ciclo_escolar_id), "uname": user.id,
    })

    # Marcar solicitud como inscrito
    await db.execute(text("""
        UPDATE ades_solicitudes_admision SET estado = 'INSCRITO', usuario_modificacion = :uname WHERE id = :id
    """), {"uname": user.id, "id": str(data.admision_id)})

    # Disparar Webhook de Inscripción
    from app.services.webhook_dispatcher import dispatch_webhook
    from datetime import date
    await dispatch_webhook("ALUMNO_INSCRITO", {
        "estudiante_id": estudiante_id,
        "matricula": f"MAT-{seq:06d}" if 'seq' in locals() else "MAT-PENDIENTE",
        "nombre": s["nombre"],
        "apellido_paterno": s["apellido_paterno"],
        "curp": s["curp"],
        "grupo_id": str(data.grupo_id),
        "ciclo_escolar_id": str(data.ciclo_escolar_id),
        "fecha_inscripcion": str(date.today())
    }, db)

    await db.commit()
    return {"message": "Preinscripción completada", "estudiante_id": estudiante_id}


# ── PE-011: Lista de espera ───────────────────────────────────────────────────

@router.get("/lista-espera")
async def lista_espera(
    plantel_id: Optional[uuid.UUID] = None,
    nivel_solicitado: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    filters = ["estado = 'LISTA_ESPERA'"]
    params: dict = {}
    if plantel_id:
        filters.append("plantel_id = :plid"); params["plid"] = str(plantel_id)
    if nivel_solicitado:
        filters.append("nivel_solicitado = :nivel"); params["nivel"] = nivel_solicitado

    r = await db.execute(text(f"""
        SELECT id, nombre, apellido_paterno, nivel_solicitado, grado_solicitado,
               nombre_tutor, telefono_tutor, email_tutor, fecha_solicitud
        FROM ades_solicitudes_admision
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_solicitud
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/lista-espera/{admision_id}/notificar", status_code=200)
async def notificar_disponibilidad(
    admision_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    sol = await db.execute(text(
        "SELECT id, email_tutor, nombre FROM ades_solicitudes_admision WHERE id = :id AND estado='LISTA_ESPERA'"
    ), {"id": str(admision_id)})
    s = sol.fetchone()
    if not s:
        raise HTTPException(status_code=404, detail="Solicitud en lista de espera no encontrada")

    sm = dict(s._mapping)
    # Encolar notificación
    await db.execute(text("""
        INSERT INTO ades_tareas_sistema
          (tipo_tarea, payload_json, estado, usuario_creacion, usuario_modificacion)
        VALUES ('NOTIFICAR_LISTA_ESPERA', :payload::jsonb, 'PENDIENTE', :uname, :uname)
    """), {
        "payload": f'{{"admision_id": "{admision_id}", "email": "{sm["email_tutor"]}", "nombre": "{sm["nombre"]}"}}',
        "uname": user.id,
    })

    await db.execute(text("""
        UPDATE ades_solicitudes_admision SET estado = 'NOTIFICADO', usuario_modificacion = :uname WHERE id = :id
    """), {"uname": user.id, "id": str(admision_id)})
    await db.commit()
    return {"message": "Notificación encolada para envío por correo"}


# ── PE-014: Materias optativas ────────────────────────────────────────────────

@router.get("/optativas")
async def listar_inscripciones_optativas(
    ciclo_id: Optional[uuid.UUID] = None,
    estudiante_id: Optional[uuid.UUID] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["io.is_active = TRUE"]
    params: dict = {}
    if ciclo_id:
        filters.append("io.ciclo_escolar_id = :cid"); params["cid"] = str(ciclo_id)
    if estudiante_id:
        filters.append("io.estudiante_id = :eid"); params["eid"] = str(estudiante_id)

    r = await db.execute(text(f"""
        SELECT io.id, io.fecha_inscripcion,
               m.nombre_materia, m.clave_materia,
               p.nombre || ' ' || p.apellido_paterno as alumno,
               e.numero_control
        FROM ades_inscripciones_optativas io
        JOIN ades_materias m ON m.id = io.materia_id
        JOIN ades_estudiantes e ON e.id = io.estudiante_id
        JOIN ades_personas p ON p.id = e.persona_id
        WHERE {" AND ".join(filters)}
        ORDER BY m.nombre_materia
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/optativas", status_code=201)
async def inscribir_optativa(
    data: OptativaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    # Verificar materia es optativa
    m = await db.execute(text(
        "SELECT id, tipo_materia FROM ades_materias WHERE id = :id AND is_active"
    ), {"id": str(data.materia_id)})
    materia = m.fetchone()
    if not materia:
        raise HTTPException(status_code=404, detail="Materia no encontrada")
    if materia._mapping.get("tipo_materia") not in ("OPTATIVA", "ELECTIVA", None):
        # Permitir si tipo_materia es NULL (retrocompatibilidad)
        pass

    # Verificar no duplicada
    dup = await db.execute(text("""
        SELECT id FROM ades_inscripciones_optativas
        WHERE estudiante_id = :eid AND materia_id = :mid AND ciclo_escolar_id = :cid AND is_active
    """), {
        "eid": str(data.estudiante_id), "mid": str(data.materia_id), "cid": str(data.ciclo_escolar_id)
    })
    if dup.fetchone():
        raise HTTPException(status_code=409, detail="El alumno ya está inscrito en esta optativa")

    r = await db.execute(text("""
        INSERT INTO ades_inscripciones_optativas
          (estudiante_id, materia_id, ciclo_escolar_id, fecha_inscripcion,
           usuario_creacion, usuario_modificacion)
        VALUES (:eid, :mid, :cid, CURRENT_DATE, :uname, :uname)
        RETURNING id
    """), {
        "eid": str(data.estudiante_id), "mid": str(data.materia_id),
        "cid": str(data.ciclo_escolar_id), "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Inscripción a optativa registrada"}


# ── PE-026: Acuerdo de convivencia ────────────────────────────────────────────

@router.post("/acuerdo-convivencia", status_code=201)
async def registrar_acuerdo_convivencia(
    data: AcuerdoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        INSERT INTO ades_acuerdos_convivencia
          (alumno_id, tutor_nombre, tutor_firma_hash, ip_firma,
           firmado_por_usuario, usuario_creacion, usuario_modificacion)
        VALUES (:aid, :tutor, :firma, :ip, :uname, :uname, :uname)
        RETURNING id
    """), {
        "aid": str(data.alumno_id), "tutor": data.tutor_nombre,
        "firma": data.tutor_firma_hash, "ip": data.ip_firma, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Acuerdo de convivencia firmado y registrado"}


# ── AC-005: Calendarios académicos ───────────────────────────────────────────

@router.get("/calendarios-academicos")
async def listar_calendarios(
    ciclo_id: Optional[uuid.UUID] = None,
    nivel_educativo: Optional[str] = None,
    tipo: Optional[str] = None,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["is_active = TRUE"]
    params: dict = {}
    if ciclo_id:
        filters.append("ciclo_escolar_id = :cid"); params["cid"] = str(ciclo_id)
    if nivel_educativo:
        filters.append("nivel_educativo = :nivel"); params["nivel"] = nivel_educativo
    if tipo:
        filters.append("tipo = :tipo"); params["tipo"] = tipo

    r = await db.execute(text(f"""
        SELECT id, nombre, tipo, nivel_educativo, fecha_inicio, fecha_fin,
               descripcion, es_oficial, fecha_creacion
        FROM ades_calendarios_academicos
        WHERE {" AND ".join(filters)}
        ORDER BY fecha_inicio
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/calendarios-academicos", status_code=201)
async def crear_evento_calendario(
    data: CalendarioAcademicoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin o superior")

    r = await db.execute(text("""
        INSERT INTO ades_calendarios_academicos
          (nombre, ciclo_escolar_id, nivel_educativo, tipo,
           fecha_inicio, fecha_fin, descripcion, es_oficial,
           usuario_creacion, usuario_modificacion)
        VALUES (:nom, :cid, :nivel, :tipo,
                :fi, :ff, :desc, :oficial, :uname, :uname)
        RETURNING id
    """), {
        "nom": data.nombre, "cid": str(data.ciclo_escolar_id),
        "nivel": data.nivel_educativo, "tipo": data.tipo,
        "fi": data.fecha_inicio, "ff": data.fecha_fin,
        "desc": data.descripcion, "oficial": data.es_oficial, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Evento de calendario registrado"}


# ── AC-014: Periodos de evaluación ───────────────────────────────────────────

@router.post("/periodos-evaluacion", status_code=201)
async def crear_periodo_evaluacion(
    data: PeriodoEvaluacionIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin o superior")

    r = await db.execute(text("""
        INSERT INTO ades_periodos_evaluacion
          (ciclo_escolar_id, nombre_periodo, nivel_educativo, tipo_evaluacion,
           fecha_inicio, fecha_fin, abierto,
           usuario_creacion, usuario_modificacion)
        VALUES (:cid, :nom, :nivel, :tipo,
                :fi, :ff, :abierto, :uname, :uname)
        RETURNING id
    """), {
        "cid": str(data.ciclo_escolar_id), "nom": data.nombre_periodo,
        "nivel": data.nivel_educativo, "tipo": data.tipo_evaluacion,
        "fi": data.fecha_inicio, "ff": data.fecha_fin,
        "abierto": data.abierto, "uname": user.id,
    })
    row = r.fetchone()
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": f"Período de evaluación {data.nombre_periodo} creado"}


@router.patch("/periodos-evaluacion/{periodo_id}/cerrar", status_code=200)
async def cerrar_periodo_evaluacion(
    periodo_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Admin o superior")

    await db.execute(text("""
        UPDATE ades_periodos_evaluacion SET abierto = FALSE, usuario_modificacion = :uname WHERE id = :id
    """), {"uname": user.id, "id": str(periodo_id)})
    await db.commit()
    return {"message": "Período de evaluación cerrado"}


# ── AC-015: Calendario de actividades ────────────────────────────────────────

@router.get("/calendario-actividades")
async def calendario_actividades(
    ciclo_id: Optional[uuid.UUID] = None,
    plantel_id: Optional[uuid.UUID] = None,
    mes: Optional[int] = Query(None, ge=1, le=12),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    filters = ["ca.is_active = TRUE"]
    params: dict = {}
    if ciclo_id:
        filters.append("ca.ciclo_escolar_id = :cid"); params["cid"] = str(ciclo_id)
    if plantel_id:
        filters.append("(ca.plantel_id = :plid OR ca.plantel_id IS NULL)"); params["plid"] = str(plantel_id)
    if mes:
        filters.append("EXTRACT(MONTH FROM ca.fecha_inicio) = :mes"); params["mes"] = mes

    r = await db.execute(text(f"""
        SELECT ca.id, ca.nombre, ca.tipo, ca.nivel_educativo,
               ca.fecha_inicio, ca.fecha_fin, ca.descripcion, ca.es_oficial,
               pl.nombre_plantel
        FROM ades_calendarios_academicos ca
        LEFT JOIN ades_planteles pl ON pl.id = ca.plantel_id
        WHERE {" AND ".join(filters)}
        ORDER BY ca.fecha_inicio
    """), params)
    return [dict(row._mapping) for row in r.fetchall()]


# ── PE-003: Evaluación Diagnóstica ──────────────────────────────────────────

@router.patch("/admision/{admision_id}/evaluacion")
async def registrar_evaluacion_diagnostica(
    admision_id: uuid.UUID,
    data: EvaluacionDiagnosticoIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")
    await db.execute(text("""
        UPDATE ades_solicitudes_admision
        SET puntuacion_diagnostico = :score,
            observaciones_diagnostico = :obs,
            estado = 'DIAGNOSTICO',
            usuario_modificacion = :uname
        WHERE id = :id
    """), {
        "score": data.puntuacion_diagnostico,
        "obs": data.observaciones_diagnostico,
        "uname": user.id,
        "id": str(admision_id)
    })
    await db.commit()
    return {"message": "Evaluación diagnóstica registrada", "estado": "DIAGNOSTICO"}


# ── PE-005: Generar Carta de Admisión ────────────────────────────────────────

@router.post("/admision/{admision_id}/carta")
async def generar_carta_admision(
    admision_id: uuid.UUID,
    template_id: str = Query(..., description="ID de la plantilla Carbone para la carta"),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT id, nombre, apellido_paterno, apellido_materno, curp, estado,
               nivel_solicitado, grado_solicitado, nombre_tutor, fecha_solicitud
        FROM ades_solicitudes_admision
        WHERE id = :id
    """), {"id": str(admision_id)})
    sol = r.fetchone()
    if not sol:
        raise HTTPException(status_code=404, detail="Solicitud no encontrada")
    s = dict(sol._mapping)
    
    payload = {
        "nombre_completo": f"{s['nombre']} {s['apellido_paterno']} {s['apellido_materno'] or ''}".strip(),
        "curp": s["curp"],
        "estado": s["estado"],
        "nivel": s["nivel_solicitado"],
        "grado": s["grado_solicitado"],
        "tutor": s["nombre_tutor"],
        "fecha": str(s["fecha_solicitud"]),
        "fecha_impresion": __import__("datetime").date.today().strftime("%d/%m/%Y"),
    }
    
    try:
        pdf_bytes = await _carbone_render(template_id, payload)
        filename = f"Carta_Admision_{s['nombre']}_{s['apellido_paterno']}.pdf".replace(" ", "_")
        return StreamingResponse(
            iter([pdf_bytes]),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Error al renderizar con Carbone: {str(e)}")


# ── PE-020: Workflow de Bajas ───────────────────────────────────────────────

@router.post("/bajas", status_code=201)
async def registrar_baja(
    data: BajaIn,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Rol Admin o superior")
    
    r = await db.execute(text("""
        INSERT INTO ades_bajas
          (estudiante_id, inscripcion_id, tipo_baja, motivo, fecha_efectiva,
           observaciones, usuario_creacion, usuario_modificacion)
        VALUES (:eid, :iid, :tipo, :motivo, :fecha::date, :obs, :uname, :uname)
        RETURNING id
    """), {
        "eid": str(data.estudiante_id),
        "iid": str(data.inscripcion_id) if data.inscripcion_id else None,
        "tipo": data.tipo_baja,
        "motivo": data.motivo,
        "fecha": data.fecha_efectiva,
        "obs": data.observaciones,
        "uname": user.id,
    })
    row = r.fetchone()
    
    # Desactivar al estudiante
    await db.execute(text("""
        UPDATE ades_estudiantes
        SET is_active = FALSE, usuario_modificacion = :uname
        WHERE id = :eid
    """), {"eid": str(data.estudiante_id), "uname": user.id})
    
    await db.commit()
    return {"id": str(row._mapping["id"]), "message": "Baja registrada con éxito. Cupo liberado."}


@router.get("/bajas")
async def listar_bajas(
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")
    r = await db.execute(text("""
        SELECT b.id, b.estudiante_id, b.tipo_baja, b.motivo, b.fecha_efectiva,
               p.nombre || ' ' || p.apellido_paterno as alumno,
               g.nombre_grupo as grupo
        FROM ades_bajas b
        JOIN ades_estudiantes e ON e.id = b.estudiante_id
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_inscripciones i ON i.id = b.inscripcion_id
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        ORDER BY b.fecha_creacion DESC
    """))
    return [dict(row._mapping) for row in r.fetchall()]


@router.post("/bajas/{baja_id}/reactivar", status_code=200)
async def reactivar_estudiante(
    baja_id: uuid.UUID,
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    if user.nivel_acceso > _NIVEL_ADMIN:
        raise HTTPException(status_code=403, detail="Se requiere Rol Admin o superior")
    
    r_baja = await db.execute(text("""
        SELECT estudiante_id, inscripcion_id FROM ades_bajas WHERE id = :bid
    """), {"bid": str(baja_id)})
    baja = r_baja.fetchone()
    if not baja:
        raise HTTPException(status_code=404, detail="Registro de baja no encontrado")
    bm = dict(baja._mapping)
    
    # Reactivar estudiante
    await db.execute(text("""
        UPDATE ades_estudiantes
        SET is_active = TRUE, usuario_modificacion = :uname
        WHERE id = :eid
    """), {"eid": bm["estudiante_id"], "uname": user.id})
    
    # Si hay una inscripción, reactivarla validando cupo
    if bm["inscripcion_id"]:
        r_ins = await db.execute(text("""
            SELECT grupo_id FROM ades_inscripciones WHERE id = :iid
        """), {"iid": bm["inscripcion_id"]})
        ins = r_ins.fetchone()
        if ins:
            gid = ins._mapping["grupo_id"]
            cap = await db.execute(text("""
                SELECT capacity.capacidad_maxima,
                       (SELECT COUNT(*) FROM ades_inscripciones WHERE grupo_id = :gid AND is_active) as inscritos
                FROM ades_grupos capacity WHERE id = :gid
            """), {"gid": str(gid)})
            grupo = cap.fetchone()
            if grupo:
                gm = dict(grupo._mapping)
                if gm["inscritos"] >= gm["capacidad_maxima"]:
                    raise HTTPException(status_code=400, detail="El grupo asignado original está lleno. No se puede reactivar la inscripción.")
                
                await db.execute(text("""
                    UPDATE ades_inscripciones
                    SET is_active = TRUE, usuario_modificacion = :uname
                    WHERE id = :iid
                """), {"iid": bm["inscripcion_id"], "uname": user.id})
    
    # Desactivar registro de baja
    await db.execute(text("""
        UPDATE ades_bajas
        SET is_active = FALSE, usuario_modificacion = :uname
        WHERE id = :bid
    """), {"bid": str(baja_id), "uname": user.id})
    
    await db.commit()
    return {"message": "Estudiante reactivado correctamente"}


# ── PE-014: Credencial Digital ───────────────────────────────────────────────

@router.get("/estudiantes/{estudiante_id}/credencial")
async def generar_credencial_estudiante(
    estudiante_id: uuid.UUID,
    template_id: str = Query(..., description="ID de la plantilla Carbone para credenciales"),
    user: AdesUser = Depends(get_ades_user),
    db: AsyncSession = Depends(get_db),
):
    r = await db.execute(text("""
        SELECT e.id, e.matricula,
               p.nombre, p.apellido_paterno, p.apellido_materno, p.curp, p.foto_url,
               g.nombre_grupo, gr.nombre_grado, c.nombre_ciclo
        FROM ades_estudiantes e
        JOIN ades_personas p ON p.id = e.persona_id
        LEFT JOIN ades_inscripciones i ON i.estudiante_id = e.id AND i.is_active = TRUE
        LEFT JOIN ades_grupos g ON g.id = i.grupo_id
        LEFT JOIN ades_grados gr ON gr.id = g.grado_id
        LEFT JOIN ades_ciclos_escolares c ON c.id = i.ciclo_escolar_id
        WHERE e.id = :id
    """), {"id": str(estudiante_id)})
    est = r.fetchone()
    if not est:
        raise HTTPException(status_code=404, detail="Estudiante no encontrado")
    s = dict(est._mapping)
    
    payload = {
        "matricula": s["matricula"] or "SIN_MATRICULA",
        "nombre_completo": f"{s['nombre']} {s['apellido_paterno']} {s['apellido_materno'] or ''}".strip(),
        "curp": s["curp"] or "",
        "foto_url": s["foto_url"] or "https://via.placeholder.com/150",
        "grupo": s["nombre_grupo"] or "",
        "grado": s["nombre_grado"] or "",
        "ciclo": s["nombre_ciclo"] or "",
        "institucion": "Instituto Nevadi",
    }
    
    try:
        pdf_bytes = await _carbone_render(template_id, payload)
        filename = f"Credencial_{s['matricula'] or s['nombre']}.pdf".replace(" ", "_")
        return StreamingResponse(
            iter([pdf_bytes]),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Error al renderizar con Carbone: {str(e)}")


# ── PE-026 (Ext.): Descarga de Expediente ZIP Individual ────────────────────────

@router.get("/estudiantes/{estudiante_id}/expediente-zip")
async def descargar_expediente_zip(
    estudiante_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: AdesUser = Depends(get_ades_user),
):
    import io
    import zipfile
    from fastapi.responses import StreamingResponse
    from app.services.paperless import descargar_documento

    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    # Obtener datos del alumno
    r_est = await db.execute(text("""
        SELECT e.matricula, p.nombre, p.apellido_paterno, p.apellido_materno
        FROM public.ades_estudiantes e
        JOIN public.ades_personas p ON p.id = e.persona_id
        WHERE e.id = :id
    """), {"id": str(estudiante_id)})
    est = r_est.fetchone()
    if not est:
        raise HTTPException(status_code=404, detail="Estudiante no encontrado")
    est_data = dict(est._mapping)
    matricula = est_data["matricula"] or str(estudiante_id)
    nombre_completo = f"{est_data['nombre']}_{est_data['apellido_paterno']}_{est_data['apellido_materno'] or ''}".strip().replace(" ", "_")

    # Obtener documentos del expediente activo
    r_docs = await db.execute(text("""
        SELECT ed.tipo_documento, ed.nombre_archivo, ed.paperless_doc_id
        FROM public.ades_expediente_documentos ed
        JOIN public.ades_expedientes_alumno ea ON ea.id = ed.expediente_id
        WHERE ea.estudiante_id = :estudiante_id
          AND ed.paperless_doc_id IS NOT NULL
    """), {"estudiante_id": str(estudiante_id)})
    docs = r_docs.fetchall()

    if not docs:
        raise HTTPException(status_code=404, detail="No se encontraron documentos en el expediente de este estudiante")

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for doc in docs:
            d = dict(doc._mapping)
            doc_bytes = await descargar_documento(d["paperless_doc_id"])
            if doc_bytes:
                # Nombre limpio dentro del zip
                ext = d["nombre_archivo"].rsplit(".", 1)[-1] if "." in d["nombre_archivo"] else "pdf"
                filename_in_zip = f"{d['tipo_documento']}.{ext}"
                zip_file.writestr(filename_in_zip, doc_bytes)

    zip_buffer.seek(0)
    filename = f"Expediente_{matricula}_{nombre_completo}.zip"
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# ── PE-026 (Ext.): Descarga de Expedientes ZIP Grupal ──────────────────────────

@router.get("/grupos/{grupo_id}/expedientes-zip")
async def descargar_expedientes_grupo_zip(
    grupo_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: AdesUser = Depends(get_ades_user),
):
    import io
    import zipfile
    from fastapi.responses import StreamingResponse
    from app.services.paperless import descargar_documento

    if user.nivel_acceso > _NIVEL_SECRETARIA:
        raise HTTPException(status_code=403, detail="Acceso denegado")

    # Obtener información del grupo
    r_grupo = await db.execute(text("""
        SELECT nombre_grupo FROM public.ades_grupos WHERE id = :id
    """), {"id": str(grupo_id)})
    g_info = r_grupo.fetchone()
    if not g_info:
        raise HTTPException(status_code=404, detail="Grupo no encontrado")
    nombre_grupo = dict(g_info._mapping)["nombre_grupo"]

    # Obtener alumnos inscritos en el grupo
    r_alumnos = await db.execute(text("""
        SELECT e.id as estudiante_id, e.matricula, p.nombre, p.apellido_paterno, p.apellido_materno
        FROM public.ades_inscripciones i
        JOIN public.ades_estudiantes e ON e.id = i.estudiante_id
        JOIN public.ades_personas p ON p.id = e.persona_id
        WHERE i.grupo_id = :grupo_id AND i.is_active = TRUE
    """), {"grupo_id": str(grupo_id)})
    alumnos = r_alumnos.fetchall()

    if not alumnos:
        raise HTTPException(status_code=404, detail="No se encontraron alumnos inscritos en este grupo")

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for al in alumnos:
            al_data = dict(al._mapping)
            est_id = al_data["estudiante_id"]
            matricula = al_data["matricula"] or str(est_id)
            nombre_completo = f"{al_data['nombre']}_{al_data['apellido_paterno']}_{al_data['apellido_materno'] or ''}".strip().replace(" ", "_")
            folder_name = f"{matricula}_{nombre_completo}"

            # Obtener documentos del expediente de este alumno
            r_docs = await db.execute(text("""
                SELECT ed.tipo_documento, ed.nombre_archivo, ed.paperless_doc_id
                FROM public.ades_expediente_documentos ed
                JOIN public.ades_expedientes_alumno ea ON ea.id = ed.expediente_id
                WHERE ea.estudiante_id = :estudiante_id
                  AND ed.paperless_doc_id IS NOT NULL
            """), {"estudiante_id": str(est_id)})
            docs = r_docs.fetchall()

            for doc in docs:
                d = dict(doc._mapping)
                doc_bytes = await descargar_documento(d["paperless_doc_id"])
                if doc_bytes:
                    ext = d["nombre_archivo"].rsplit(".", 1)[-1] if "." in d["nombre_archivo"] else "pdf"
                    filename_in_zip = f"{folder_name}/{d['tipo_documento']}.{ext}"
                    zip_file.writestr(filename_in_zip, doc_bytes)

    zip_buffer.seek(0)
    filename = f"Expedientes_Grupo_{nombre_grupo}.zip"
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
