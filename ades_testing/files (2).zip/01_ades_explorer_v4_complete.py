#!/usr/bin/env python3
"""
01_ADES_EXPLORER_V4.PY - TESTING COMPLETO DE MODALES
Soporta:
  - Autenticación Authentik (3 pasos)
  - Detección y apertura de modales laterales (side panels)
  - Detección y apertura de modales centrales
  - Iteración sobre pestañas dentro de modales
  - Validación de campos en cada pestaña
  - Captura de estado de cada pestaña
  - Detección de inconsistencias dentro de modales
"""

import os
import json
import asyncio
import base64
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

from playwright.async_api import async_playwright, Page, BrowserContext
from dotenv import load_dotenv
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

SCRIPT_DIR = Path(__file__).parent.absolute()
OUTPUT_DIR = SCRIPT_DIR / "captures"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

env_file = SCRIPT_DIR / ".env"
if env_file.exists():
    load_dotenv(env_file)
    logger.info(f"✓ Archivo .env cargado")

ADES_USER = os.getenv("ADES_USER", "admin")
ADES_PASSWORD = os.getenv("ADES_PASSWORD", "")
BASE_URL = "https://ades.setag.mx"

logger.info(f"Working directory: {SCRIPT_DIR}")


class AdesExplorerV4:
    def __init__(self):
        self.config = self._load_config()
        self.captures: List[Dict[str, Any]] = []
        self.errors: List[Dict[str, Any]] = []

    def _load_config(self) -> Dict:
        config_path = SCRIPT_DIR / "config_ades_modules.json"
        with open(config_path) as f:
            return json.load(f)

    async def run(self, phase: int = 1, limit: int = None):
        async with async_playwright() as p:
            logger.info(f"Iniciando Playwright en {BASE_URL}")
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(viewport={"width": 1920, "height": 1080})
            page = await context.new_page()
            
            try:
                logger.info("Autenticando en ADES (Authentik - 3 pasos)...")
                await self._authenticate_authentik(page)
                
                modules_to_test = [
                    m for m in self.config["modules"]
                    if self._get_phase(m["risk"]) <= phase
                ]
                modules_to_test.sort(key=lambda m: m["sequence"])
                
                if limit:
                    modules_to_test = modules_to_test[:limit]
                
                logger.info(f"Testeando {len(modules_to_test)} módulos (Fase {phase})")
                
                for i, module in enumerate(modules_to_test, 1):
                    logger.info(f"\n[{i}/{len(modules_to_test)}] {module['id']}")
                    await self._capture_module_with_modals(page, module)
                    await asyncio.sleep(0.5)
                
                await self._save_results()
                
            except Exception as e:
                logger.error(f"Error: {e}")
                raise
            finally:
                await context.close()
                await browser.close()

    async def _authenticate_authentik(self, page: Page):
        """Autenticación Authentik - 3 pasos."""
        try:
            logger.info("Paso 1: Navegando a login y buscando botón de institucion...")
            await page.goto(f"{BASE_URL}/login", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            button_selectors = [
                'button:has-text("Iniciar sesión con cuenta institucional")',
                'button:has-text("Iniciar sesión")',
                'a:has-text("Iniciar sesión con cuenta institucional")'
            ]
            
            for selector in button_selectors:
                try:
                    if await page.query_selector(selector):
                        logger.info(f"  ✓ Botón encontrado")
                        await page.click(selector)
                        await asyncio.sleep(2)
                        break
                except:
                    continue
            
            logger.info("Paso 2: Ingresando username...")
            await page.wait_for_selector('input[type="text"], input[type="email"]', timeout=30000)
            email_field = await page.query_selector('input[type="text"]') or await page.query_selector('input[type="email"]')
            await page.fill(await email_field.evaluate('el => el.getAttribute("name") or el.id or "input"'), ADES_USER)
            
            submit_buttons = ['button:has-text("Continuar")', 'button[type="submit"]']
            for selector in submit_buttons:
                if await page.query_selector(selector):
                    await page.click(selector)
                    await asyncio.sleep(2)
                    break
            
            logger.info("Paso 3: Ingresando contraseña...")
            await page.wait_for_selector('input[type="password"]', timeout=30000)
            await page.fill('input[type="password"]', ADES_PASSWORD)
            
            for selector in submit_buttons:
                if await page.query_selector(selector):
                    await page.click(selector)
                    break
            
            logger.info("Esperando dashboard...")
            try:
                await page.wait_for_url(lambda url: "/dashboard" in str(url), timeout=60000)
            except:
                await page.wait_for_load_state("networkidle", timeout=30000)
            
            await asyncio.sleep(3)
            logger.info("✓ Autenticación exitosa")
            
        except Exception as e:
            logger.error(f"✗ Error autenticación: {e}")
            raise

    async def _capture_module_with_modals(self, page: Page, module: Dict[str, Any]):
        """Capturar módulo + Testing de modales laterales Y centrales."""
        try:
            url = f"{BASE_URL}{module['path']}"
            logger.info(f"  Navegando a {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # Captura principal
            screenshot = await page.screenshot()
            visible_text = await page.evaluate("() => document.body.innerText")
            
            # Detectar y testear modales
            modal_info = await self._test_all_modals(page)
            
            capture = {
                "module_id": module["id"],
                "module_path": module["path"],
                "timestamp": datetime.now().isoformat(),
                "screenshot_base64": base64.b64encode(screenshot).decode(),
                "visible_text_sample": visible_text[:1000],
                "modals_detected": modal_info["count"],
                "side_panels_detected": modal_info["side_panels"],
                "central_modals_detected": modal_info["central_modals"],
                "modals_with_tabs": modal_info["with_tabs"],
                "tab_info": modal_info["tab_details"],
                "modal_inconsistencies": modal_info["inconsistencies"],
                "success": True
            }
            
            self.captures.append(capture)
            
            screenshot_path = OUTPUT_DIR / f"{module['id']}.png"
            with open(screenshot_path, "wb") as f:
                f.write(screenshot)
            
            summary = f"  ✓ Capturado"
            if modal_info["count"] > 0:
                summary += f" | Modales: {modal_info['count']}"
                if modal_info["side_panels"] > 0:
                    summary += f" (laterales: {modal_info['side_panels']}"
                    if modal_info["with_tabs"] > 0:
                        summary += f", con {modal_info['with_tabs']} pestañas"
                    summary += ")"
                if modal_info["central_modals"] > 0:
                    summary += f" (centrales: {modal_info['central_modals']})"
            
            if modal_info["inconsistencies"]:
                summary += f" | ⚠️ {len(modal_info['inconsistencies'])} inconsistencias"
            
            logger.info(summary)
            
        except Exception as e:
            logger.error(f"  ✗ Error: {e}")
            self.errors.append({"module_id": module["id"], "error": str(e)})

    async def _test_all_modals(self, page: Page) -> Dict[str, Any]:
        """Detectar y testear todos los modales (laterales + centrales)."""
        result = {
            "count": 0,
            "side_panels": 0,
            "central_modals": 0,
            "with_tabs": 0,
            "tab_details": [],
            "inconsistencies": []
        }
        
        try:
            # Buscar botones de edición (lápices, etc)
            edit_buttons = await page.query_selector_all(
                'button[title*="ditar"], button[aria-label*="dit"], .edit-btn, [class*="edit"]'
            )
            
            # Límite de 3 modales para no tardar mucho
            max_modals_to_test = min(3, len(edit_buttons))
            
            for i in range(max_modals_to_test):
                try:
                    # Re-encontrar el botón (puede haber cambios en DOM)
                    edit_buttons = await page.query_selector_all(
                        'button[title*="ditar"], button[aria-label*="dit"], .edit-btn, [class*="edit"], [role="button"]'
                    )
                    
                    if i < len(edit_buttons):
                        button = edit_buttons[i]
                        await button.scroll_into_view()
                        await asyncio.sleep(0.5)
                        await button.click()
                        await asyncio.sleep(1.5)
                        
                        # Detectar tipo de modal abierto
                        modal_type = await self._detect_modal_type(page)
                        
                        if modal_type == "side_panel":
                            result["side_panels"] += 1
                            tab_info = await self._test_tabbed_modal(page)
                            result["tab_details"].append(tab_info)
                            if tab_info["tabs_found"] > 0:
                                result["with_tabs"] += 1
                        elif modal_type == "central":
                            result["central_modals"] += 1
                        
                        result["count"] += 1
                        
                        # Cerrar modal
                        await self._close_modal(page)
                        await asyncio.sleep(0.5)
                        
                except Exception as e:
                    logger.debug(f"  Error testeando modal {i}: {e}")
                    continue
            
        except Exception as e:
            logger.debug(f"Error en _test_all_modals: {e}")
        
        return result

    async def _detect_modal_type(self, page: Page) -> str:
        """Detectar tipo de modal: side_panel o central."""
        try:
            # Verificar side panel
            side_panel = await page.query_selector('[role="dialog"]:right-of-viewport, .drawer, .side-panel, [class*="drawer"]')
            if side_panel:
                return "side_panel"
            
            # Verificar modal central
            central_modal = await page.query_selector('[role="dialog"], .modal')
            if central_modal:
                return "central"
            
            return "unknown"
        except:
            return "unknown"

    async def _test_tabbed_modal(self, page: Page) -> Dict[str, Any]:
        """Testear modal con pestañas."""
        tab_info = {
            "tabs_found": 0,
            "tabs_tested": [],
            "fields_per_tab": {},
            "empty_fields": []
        }
        
        try:
            # Buscar pestañas
            tab_buttons = await page.query_selector_all('[role="tab"], .tab, .nav-tabs li a, [class*="tab"]')
            tab_info["tabs_found"] = len(tab_buttons)
            
            for idx, tab_btn in enumerate(tab_buttons[:5]):  # Max 5 pestañas
                try:
                    tab_name = await tab_btn.text_content()
                    await tab_btn.click()
                    await asyncio.sleep(0.5)
                    
                    # Contar campos en esta pestaña
                    fields = await page.query_selector_all('input, textarea, select')
                    empty_fields = []
                    
                    for field in fields:
                        value = await field.input_value() if await field.get_attribute('type') != 'hidden' else ""
                        if not value or value.strip() == "":
                            field_name = await field.get_attribute('name') or await field.get_attribute('id') or f"field_{idx}"
                            empty_fields.append(field_name)
                    
                    tab_info["tabs_tested"].append(tab_name.strip() if tab_name else f"Tab {idx+1}")
                    tab_info["fields_per_tab"][tab_name.strip() if tab_name else f"Tab {idx+1}"] = len(fields)
                    
                    if empty_fields:
                        tab_info["empty_fields"].extend([(tab_name or f"Tab {idx+1}", f) for f in empty_fields])
                
                except Exception as e:
                    logger.debug(f"Error en pestaña {idx}: {e}")
                    continue
        
        except Exception as e:
            logger.debug(f"Error en _test_tabbed_modal: {e}")
        
        return tab_info

    async def _close_modal(self, page: Page):
        """Cerrar modal abierto."""
        try:
            # Buscar botón cerrar
            close_buttons = [
                'button[aria-label*="Close"]',
                'button[aria-label*="close"]',
                '.close',
                'button:has(svg)',
                '[role="dialog"] button:nth-child(1)'
            ]
            
            for selector in close_buttons:
                try:
                    btn = await page.query_selector(selector)
                    if btn:
                        await btn.click()
                        await asyncio.sleep(0.5)
                        return
                except:
                    continue
            
            # Si no encuentra botón, presionar Escape
            await page.press('body', 'Escape')
        except:
            pass

    async def _save_results(self):
        """Guardar resultados."""
        summary = {
            "timestamp": datetime.now().isoformat(),
            "total_modules": len(self.captures),
            "successful": len([c for c in self.captures if c["success"]]),
            "modules_with_modals": len([c for c in self.captures if c["modals_detected"] > 0]),
            "modules_with_side_panels": len([c for c in self.captures if c["side_panels_detected"] > 0]),
            "modules_with_tabbed_modals": len([c for c in self.captures if c["modals_with_tabs"] > 0])
        }
        
        results = {"summary": summary, "captures": self.captures}
        
        results_path = OUTPUT_DIR / "captures_summary.json"
        with open(results_path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        logger.info(f"\n✓ Resultados guardados")
        logger.info(f"  - Módulos: {summary['successful']}/{summary['total_modules']}")
        logger.info(f"  - Con modales: {summary['modules_with_modals']}")
        logger.info(f"  - Con side panels: {summary['modules_with_side_panels']}")
        logger.info(f"  - Con pestañas: {summary['modules_with_tabbed_modals']}")

    def _get_phase(self, risk: str) -> int:
        return {"critico": 1, "alto": 1, "medio": 2, "bajo": 3}.get(risk, 3)


async def main():
    if not ADES_PASSWORD:
        raise ValueError("ADES_PASSWORD no configurada")
    
    explorer = AdesExplorerV4()
    
    # OPCIONES DE EJECUCIÓN:
    # phase=1, limit=None  → Todos los módulos críticos/altos (~25) → 30-40 min
    # phase=1, limit=25    → Primeros 25 módulos → 30-40 min
    # phase=1, limit=5     → Test rápido (5 módulos) → 5-10 min
    # phase=1, limit=10    → Test medio (10 módulos) → 15-20 min
    
    logger.info("=== OPCIONES DE EJECUCIÓN ===")
    logger.info("Fase 1 (críticos/altos): ~25 módulos en 30-40 minutos")
    logger.info("Fase 2 (medios): +15 módulos en 20-30 minutos")
    logger.info("Fase 3 (bajos): +20 módulos en 25-35 minutos")
    logger.info("=== EJECUTANDO FASE 1 (ALL) ===\n")
    
    await explorer.run(phase=1, limit=None)  # None = sin límite, testea TODO fase 1


if __name__ == "__main__":
    asyncio.run(main())
